import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Label } from '@/components/ui/label';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { CheckCircle, Calculator, DollarSign } from 'lucide-react';
import { ROLE_PROFILES, getRoleProfile } from '@/lib/roleConstants';

interface QuestionOption {
  id: string;
  label: string;
  weight: number;
}

interface Question {
  id: string;
  text: string;
  options: QuestionOption[];
}

const questions: Question[] = [
  {
    id: 'role_type',
    text: 'Who gets the time back from this AI implementation?',
    options: [
      { id: 'data_entry_admin', label: 'Data Entry Clerk / Admin Assistant', weight: 0 },
      { id: 'accounts_payable_receivable', label: 'Accounts Payable/Receivable Clerk', weight: 1 },
      { id: 'payroll_specialist', label: 'Payroll Specialist / Coordinator', weight: 2 },
      { id: 'customer_support_t1', label: 'Customer Support Agent (Tier 1)', weight: 3 },
      { id: 'sales_ops_crm', label: 'Sales Operations / CRM Administrator', weight: 4 },
      { id: 'procurement_purchasing', label: 'Procurement / Purchasing Agent', weight: 5 },
      { id: 'hr_coordinator', label: 'HR Coordinator / Generalist', weight: 6 },
      { id: 'it_support_helpdesk', label: 'IT Support / Help Desk (Tier 1-2)', weight: 7 },
      { id: 'operations_coordinator', label: 'Operations Coordinator / Analyst', weight: 8 },
      { id: 'marketing_ops', label: 'Marketing Operations Specialist', weight: 9 },
      { id: 'financial_analyst', label: 'Financial Analyst / FP&A', weight: 10 },
      { id: 'customer_success', label: 'Customer Success Manager', weight: 11 },
      { id: 'executive_assistant', label: 'Executive Assistant / Office Manager', weight: 12 },
      { id: 'compliance_qa_audit', label: 'Compliance / QA / Audit Specialist', weight: 13 },
      { id: 'legal_contract_admin', label: 'Legal / Contract Administrator', weight: 14 },
      { id: 'other', label: 'Other (specify in comments)', weight: 15 }
    ]
  },
  {
    id: 'capacity_demand',
    text: 'What is the relationship between current capacity and available opportunities?',
    options: [
      { id: 'high_demand_at_capacity', label: 'High demand with team at/above capacity (turning away opportunities, clear revenue potential)', weight: 1.4 },
      { id: 'strong_pipeline_near_capacity', label: 'Strong pipeline with team near capacity (could pursue more with freed time)', weight: 1.2 },
      { id: 'moderate_opportunities', label: 'Moderate opportunities with balanced capacity (some room to grow)', weight: 0.9 },
      { id: 'limited_opportunities', label: 'Limited opportunities or low utilization (team has spare capacity or demand is constrained)', weight: 0.4 }
    ]
  },
  {
    id: 'revenue_process',
    text: 'How does more time translate to more revenue?',
    options: [
      { id: 'direct_predictable', label: 'Direct & predictable (Example: More hours = more billable consulting, more service appointments, more deals closed)', weight: 1.2 },
      { id: 'somewhat_predictable', label: 'Somewhat predictable (Example: More time helps close deals faster or handle more accounts, but other factors also matter)', weight: 1.0 },
      { id: 'indirect_complex', label: 'Indirect or complex (Example: Long sales cycles with many stakeholders, revenue depends on market timing, not just time invested)', weight: 0.7 },
      { id: 'limited_factors', label: 'Limited by other factors (Example: Can\'t sell more due to limited inventory, small market, regulatory constraints, or lead availability)', weight: 0.4 }
    ]
  }
];

interface RevenueUpliftRubricProps {
  onReallocationCalculated: (percentage: number) => void;
}

export default function RevenueUpliftRubric({ onReallocationCalculated }: RevenueUpliftRubricProps) {
  const [currentStep, setCurrentStep] = useState(0);
  const [answers, setAnswers] = useState<Record<string, string>>({});
  const [calculatedPercentage, setCalculatedPercentage] = useState<number | null>(null);
  const [selectedRole, setSelectedRole] = useState<typeof ROLE_PROFILES[0] | null>(null);

  const handleAnswer = (questionId: string, optionId: string) => {
    setAnswers(prev => ({ ...prev, [questionId]: optionId }));
  };

  const goToNextStep = () => {
    if (currentStep < questions.length - 1) {
      setCurrentStep(currentStep + 1);
    } else {
      calculateReallocation();
    }
  };

  const goToPreviousStep = () => {
    if (currentStep > 0) {
      setCurrentStep(currentStep - 1);
    }
  };

  const calculateReallocation = () => {
    // Validate all questions are answered (now 3 questions instead of 4)
    const requiredQuestions = ['role_type', 'capacity_demand', 'revenue_process'];
    const missingAnswers = requiredQuestions.filter(q => !answers[q]);
    
    if (missingAnswers.length > 0) {
      console.error('Cannot calculate: missing answers for', missingAnswers);
      return;
    }

    const roleTypeAnswer = answers['role_type'];
    
    // Get role profile using the role ID
    const roleProfile = getRoleProfile(roleTypeAnswer);
    if (!roleProfile) {
      console.error('Invalid role type:', roleTypeAnswer);
      return;
    }

    // If base percentage is 0 (pure support or none), result is always 0
    if (roleProfile.revenueUpliftBase === 0) {
      setCalculatedPercentage(0);
      setSelectedRole(roleProfile);
      return;
    }

    // Calculate the final percentage based on all answers
    let basePercentage = roleProfile.revenueUpliftBase;
    
    // Apply multipliers from other questions (consolidated capacity/demand + revenue process)
    const capacityDemandWeight = questions[1].options.find(opt => opt.id === answers['capacity_demand'])?.weight;
    const revenueProcessWeight = questions[2].options.find(opt => opt.id === answers['revenue_process'])?.weight;
    
    if (capacityDemandWeight === undefined || revenueProcessWeight === undefined) {
      console.error('Failed to find weights for answers');
      return;
    }
    
    const finalPercentage = Math.round(basePercentage * capacityDemandWeight * revenueProcessWeight);
    
    // Extract role-specific bounds from revenueUpliftRange
    const rangeParts = roleProfile.revenueUpliftRange.match(/(\d+)%(?:\s*-\s*(\d+)%)?/);
    const minPercent = 0;
    const maxPercent = rangeParts ? (rangeParts[2] ? parseInt(rangeParts[2]) : parseInt(rangeParts[1])) : 60;
    
    // Cap the percentage within role-specific bounds
    const cappedPercentage = Math.min(Math.max(finalPercentage, minPercent), maxPercent);
    
    setCalculatedPercentage(cappedPercentage);
    setSelectedRole(roleProfile);
  };

  const applyReallocation = () => {
    if (calculatedPercentage !== null) {
      onReallocationCalculated(calculatedPercentage);
    }
  };

  const resetQuestionnaire = () => {
    setCurrentStep(0);
    setAnswers({});
    setCalculatedPercentage(null);
    setSelectedRole(null);
  };

  const currentQuestion = questions[currentStep];
  const isLastStep = currentStep === questions.length - 1;
  const canProceed = answers[currentQuestion?.id];

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <DollarSign className="h-5 w-5 text-primary" />
          Revenue Uplift Rubric
        </CardTitle>
        <CardDescription>
          Answer questions to determine if and how much saved time can realistically convert to revenue generation
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        {calculatedPercentage === null ? (
          <>
            {/* Progress Indicator */}
            <div className="flex items-center justify-between text-sm text-muted-foreground">
              <span>Question {currentStep + 1} of {questions.length}</span>
              <div className="flex gap-1">
                {questions.map((_, index) => (
                  <div
                    key={index}
                    className={`w-2 h-2 rounded-full ${
                      index <= currentStep ? 'bg-primary' : 'bg-muted'
                    }`}
                  />
                ))}
              </div>
            </div>

            {/* Current Question */}
            <div className="space-y-4">
              <Label className="text-base font-medium">{currentQuestion.text}</Label>
              
              <RadioGroup
                value={answers[currentQuestion.id] || ''}
                onValueChange={(value) => handleAnswer(currentQuestion.id, value)}
                className="space-y-3"
              >
                {currentQuestion.options.map((option) => (
                  <div key={option.id} className="flex items-start space-x-3">
                    <RadioGroupItem
                      value={option.id}
                      id={option.id}
                      className="mt-1"
                      data-testid={`radio-${option.id}`}
                    />
                    <Label 
                      htmlFor={option.id} 
                      className="flex-1 text-sm leading-relaxed cursor-pointer"
                    >
                      {option.label}
                    </Label>
                  </div>
                ))}
              </RadioGroup>
            </div>

            {/* Navigation Buttons */}
            <div className="flex gap-3">
              <Button
                variant="outline"
                onClick={goToPreviousStep}
                disabled={currentStep === 0}
                className="flex-1"
                data-testid="button-previous"
              >
                Previous
              </Button>
              <Button
                onClick={goToNextStep}
                disabled={!canProceed}
                className="flex-1"
                data-testid={isLastStep ? "button-calculate" : "button-next"}
              >
                {isLastStep ? 'Calculate Reallocation' : 'Next'}
              </Button>
            </div>
          </>
        ) : (
          // Results Display
          <div className="space-y-6">
            <div className="text-center space-y-4">
              <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-primary/10">
                <CheckCircle className="h-8 w-8 text-primary" />
              </div>
              
              <div>
                <h3 className="text-2xl font-bold text-primary" data-testid="text-calculated-percentage">
                  {calculatedPercentage}%
                </h3>
                <p className="text-sm text-muted-foreground">Estimated Time Reallocation to Revenue Activities</p>
              </div>
            </div>

            {selectedRole && (
              <div className="p-4 border rounded-lg bg-muted/20 space-y-3">
                <div className="flex items-center justify-between">
                  <h4 className="font-medium">{selectedRole.role}</h4>
                  <Badge variant="secondary">{selectedRole.revenueUpliftRange}</Badge>
                </div>
                <p className="text-sm text-muted-foreground">
                  {selectedRole.description}
                </p>
              </div>
            )}

            <div className="flex gap-3">
              <Button
                variant="outline"
                onClick={resetQuestionnaire}
                className="flex-1"
                data-testid="button-retake"
              >
                Retake Assessment
              </Button>
              <Button
                onClick={applyReallocation}
                className="flex-1"
                data-testid="button-apply-reallocation"
              >
                Apply Reallocation
              </Button>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
