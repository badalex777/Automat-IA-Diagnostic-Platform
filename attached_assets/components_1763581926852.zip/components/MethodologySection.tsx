import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Separator } from '@/components/ui/separator';
import { Info, Calculator, BookOpen, Target, TrendingUp, Zap, RefreshCw, DollarSign, FileText, Download, Shield } from 'lucide-react';
import { generateCompanyHandbook } from '@/lib/handbookGenerator';

export default function MethodologySection() {
  return (
    <div className="space-y-8 mt-12">
      <div className="text-center">
        <h2 className="text-2xl font-bold mb-2">About This ROI Calculator</h2>
        <p className="text-muted-foreground">Understanding the methodology and evaluation criteria</p>
      </div>
      {/* 1. What This ROI Calculator Provides */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Info className="h-5 w-5 text-primary" />
            What This ROI Calculator Provides
          </CardTitle>
        </CardHeader>
        <CardContent className="prose prose-sm max-w-none dark:prose-invert">
          <p>
            The Automat-IA ROI Calculator is a comprehensive tool designed specifically for SMEs (10-200 employees) 
            to evaluate the financial impact of AI implementation projects in back-office operations. It provides 
            conservative, directional estimates that help businesses make informed decisions about automation investments.
          </p>
          <p>
            Unlike generic ROI calculators, this tool focuses on <strong>transparent calculations</strong> with 
            <strong> mandatory source tracking</strong> for every input, ensuring credible and auditable results. 
            The calculator uses industry-standard methodologies and scenario modeling to provide realistic ROI projections.
          </p>
        </CardContent>
      </Card>
      {/* 2. How It Works: Conservative Estimates First, Scenarios Second */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Calculator className="h-5 w-5 text-primary" />
            How It Works: Conservative Estimates First, Scenarios Second
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <h4 className="font-semibold mb-2">Core Calculation Method</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li>• <strong>Effective Hourly Rate:</strong> Salary + overhead costs per hour</li>
                <li>• <strong>Benefits:</strong> Time savings + quality impact + revenue gains</li>
                <li>• <strong>Costs:</strong> Implementation + software + training + change management</li>
                <li>• <strong>ROI:</strong> (Net Benefits ÷ Total Costs) × 100</li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-2">Scenario Modeling</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li>• <strong>Best Case:</strong> 15-20% higher benefits, 5% lower costs</li>
                <li>• <strong>Base Case:</strong> Input values used as-is (most realistic)</li>
                <li>• <strong>Conservative:</strong> 30% lower benefits, 10% higher costs</li>
                <li>• <strong>Worst Case:</strong> 50-60% lower benefits, 20% higher costs</li>
              </ul>
            </div>
          </div>
          
          <Separator className="my-4" />
          
          <div>
            <h4 className="font-semibold mb-3">Multi-Year Projections (Years 1, 3, 5)</h4>
            <p className="text-sm text-muted-foreground mb-3">
              The calculator projects ROI over Years 1, 3, and 5 to support strategic AI implementations with longer payback periods. 
              All scenario multipliers (Best/Base/Conservative/Worst) remain applied throughout the projection period, ensuring consistency.
            </p>
            
            <div className="bg-primary/5 p-3 rounded-md mb-4 border border-primary/20">
              <h5 className="text-sm font-semibold mb-2">How Multi-Year Calculations Work</h5>
              <ul className="text-xs text-muted-foreground space-y-1">
                <li>• <strong>Baseline Ramp-Up:</strong> Gradual adoption is modeled as 50% average efficiency during ramp-up months, 100% after. Example: 18-month ramp-up = Year 1 at 50%, Year 2 at 75%, Year 3+ at 100%.</li>
                <li>• <strong>Organizational Readiness Adjustment:</strong> The ramp-up efficiency rubric (20-150%) <em>multiplies</em> the baseline Year 1 factor based on implementation complexity, digital comfort, rollout approach, and support. Higher efficiency = faster value realization. Lower efficiency = slower adoption.</li>
                <li>• <strong>Scenario Adjustment:</strong> Your selected scenario further adjusts the efficiency multiplier (Best: +15%, Conservative: -20%, Worst: -30%).</li>
                <li>• <strong>Final Year 1 Factor:</strong> Baseline ramp factor × Efficiency multiplier = Year 1 benefit realization. Example: 6-month ramp (75% base) × 80% efficiency = 60% Year 1 benefits.</li>
              </ul>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="bg-muted p-3 rounded-md">
                <h5 className="text-sm font-semibold mb-2">Year 1 Ramp-Up Modeling</h5>
                <p className="text-xs text-muted-foreground">
                  Year 1 benefits are adjusted to reflect gradual adoption during implementation. For example, a 6-month implementation 
                  assumes 6 months of full production plus partial benefits during the ramp-up period. This accounts for the reality 
                  that teams don't achieve full efficiency on day one. The ramp-up efficiency multiplier further adjusts based on 
                  organizational readiness factors (implementation complexity, digital comfort, rollout approach, and support structure).
                </p>
              </div>
              <div className="bg-muted p-3 rounded-md">
                <h5 className="text-sm font-semibold mb-2">Full Run-Rate (Years 2+)</h5>
                <p className="text-xs text-muted-foreground">
                  Full run-rate benefits (100% of scenario-adjusted annual benefits) begin only after the ramp-up period completes. 
                  For implementations with ramp-up periods longer than 12 months, Year 2 may still show partial benefits until the 
                  ramp-up is complete. Once fully operational, processes are optimized and user adoption is complete, delivering 
                  consistent steady-state benefits.
                </p>
              </div>
              <div className="bg-muted p-3 rounded-md">
                <h5 className="text-sm font-semibold mb-2">Cost Evolution</h5>
                <p className="text-xs text-muted-foreground">
                  <strong>Year 1:</strong> Includes all one-time costs (implementation, training, change management) plus the first year of annual software costs.
                  <br/><br/>
                  <strong>Years 2-5:</strong> Only annual software costs apply. One-time implementation costs are not repeated, which dramatically improves net benefits in later years.
                </p>
              </div>
              <div className="bg-muted p-3 rounded-md">
                <h5 className="text-sm font-semibold mb-2">Payback Calculation</h5>
                <p className="text-xs text-muted-foreground">
                  The payback period identifies when cumulative benefits equal cumulative costs (the breakeven point). The calculator uses 
                  monthly precision to find the exact month when the initial investment is fully recovered. This provides precise timing 
                  (for example, 14.3 months instead of just "Year 2") to support financial planning and budgeting decisions.
                </p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
      {/* 3. Step-by-Step User Guide: From Process to ROI (FIXED - 6 steps) */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <BookOpen className="h-5 w-5 text-primary" />
            Step-by-Step User Guide: From Process to ROI
          </CardTitle>
          <CardDescription>
            Six straightforward steps to complete your ROI analysis
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <Badge variant="outline" className="mb-2">Steps 1-3: Foundation</Badge>
                <ol className="space-y-3 text-sm">
                  <li><strong>1. Process Information:</strong> Define the specific process you're automating and select your scenario (Best/Base/Conservative/Worst)</li>
                  <li><strong>2. People & Costs:</strong> Enter employee data, hourly rates, and overhead multipliers</li>
                  <li><strong>3. Implementation Costs & Ramp-up:</strong> Input software costs, training, change management, and ramp-up duration</li>
                </ol>
              </div>
              <div>
                <Badge variant="outline" className="mb-2">Steps 4-6: Benefits</Badge>
                <ol className="space-y-3 text-sm" start={4}>
                  <li><strong>4. Time Savings:</strong> Enable and configure percentage of time saved (use rubric for guidance)</li>
                  <li><strong>5. Quality Impact:</strong> Configure error rates and quality improvement if applicable</li>
                  <li><strong>6. Revenue Uplift:</strong> Add revenue conversion potential if time savings can translate to revenue</li>
                </ol>
                <p className="text-xs text-muted-foreground mt-3">
                  <strong>Tip:</strong> Use the "Use Assessment Rubric" buttons for data-driven estimates instead of guessing percentages.
                </p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
      {/* 4. Why These Rubrics Provide Reliable Estimates (WITH INTRO) */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Target className="h-5 w-5 text-green-600" />
            Why These Rubrics Provide Reliable Estimates
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="bg-primary/5 p-4 rounded-md border border-primary/20">
            <h4 className="font-semibold mb-2">What Are Assessment Rubrics?</h4>
            <p className="text-sm text-muted-foreground">
              Assessment rubrics are structured evaluation frameworks that transform subjective judgments into consistent, 
              data-driven estimates. Instead of asking "What percentage of time will AI save?" and hoping for accurate guesses, 
              rubrics ask specific, answerable questions about process characteristics - then calculate realistic percentages 
              based on research-backed patterns.
            </p>
            <p className="text-sm text-muted-foreground mt-2">
              Our ROI Calculator includes four specialized rubrics: <strong>AI Time Saved</strong> (automation potential), 
              <strong>Quality Impact</strong> (error reduction), <strong>Revenue Uplift</strong> (revenue reallocation), 
              and <strong>Ramp-Up Efficiency</strong> (implementation smoothness). Each rubric uses industry research, 
              process-type analysis, and conservative multipliers to generate defensible estimates that withstand scrutiny.
            </p>
          </div>
          
          <Separator />

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <h4 className="font-semibold mb-2">Data-Driven Approach</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li>• Based on real-world AI implementation patterns</li>
                <li>• Category-specific base rates from industry studies</li>
                <li>• Conservative capping prevents unrealistic estimates</li>
                <li>• Multi-factor analysis considers process nuances</li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-2">Professional Credibility</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li>• Eliminates guesswork and subjective estimates</li>
                <li>• Provides consistent methodology across projects</li>
                <li>• Transparent calculation logic for client trust</li>
                <li>• Defensible estimates for business cases</li>
              </ul>
            </div>
          </div>
          <div className="bg-primary/5 p-4 rounded-md">
            <p className="text-sm">
              <strong>Remember:</strong> These rubrics provide <em>directional estimates</em> to guide decision-making. 
              Actual results will vary based on implementation quality, user adoption, and process specifics. 
              Always validate estimates with pilot programs when possible.
            </p>
          </div>
        </CardContent>
      </Card>
      {/* 5. Understanding Role-Based Classification */}
      <Card id="role-based-classification" className="border-primary/20 bg-primary/5 scroll-mt-4">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-primary">
            <Info className="h-5 w-5" />
            Understanding Role-Based Classification
          </CardTitle>
          <CardDescription>
            15-role taxonomy shared by Time Savings, Quality Impact, and Revenue Uplift rubrics
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="bg-blue-50 dark:bg-blue-950/20 p-4 rounded-md border border-blue-200 dark:border-blue-900 mb-4">
            <p className="text-sm font-semibold mb-2">📋 Applies to Time Savings, Quality Impact, and Revenue Uplift Rubrics</p>
            <p className="text-xs text-muted-foreground">
              The role-based classification system below is used as Question 1 in the <strong>AI Time Saved Rubric</strong>, 
              the <strong>Quality Impact Rubric</strong>, and the <strong>Revenue Uplift Rubric</strong>. This unified approach 
              eliminates redundant questions and provides consistent baseline data aligned with your actual job roles.
            </p>
          </div>

          <p className="text-sm">
            <strong>Why Roles Instead of Process Types:</strong> This calculator now asks "Which role best describes the work performed 
            in this step?" instead of "What type of process will be automated?" This role-based approach directly maps to your data 
            collection forms, making it easier to classify work and ensuring consistency across multiple automation assessments.
          </p>
          <p className="text-sm text-muted-foreground mb-4">
            While all three rubrics use the same role question, the <strong>base percentages are calibrated differently</strong> 
            for time savings, quality improvement, and revenue uplift. The table below shows all three perspectives for each of the 15 roles, 
            ranked from highest to lowest automation potential.
          </p>

          <div className="space-y-3">
            <h4 className="font-semibold mb-3">Complete 15-Role Taxonomy with Base Percentages</h4>
            
            <div className="overflow-x-auto">
              <table className="w-full text-xs border-collapse">
                <thead>
                  <tr className="border-b-2">
                    <th className="text-left p-2 font-semibold">Role</th>
                    <th className="text-center p-2 font-semibold">Time Savings</th>
                    <th className="text-center p-2 font-semibold">Quality Impact</th>
                    <th className="text-center p-2 font-semibold">Revenue Uplift</th>
                    <th className="text-left p-2 font-semibold">Description</th>
                  </tr>
                </thead>
                <tbody className="divide-y">
                  <tr className="hover-elevate">
                    <td className="p-2 font-medium">Data Entry Clerk / Admin Assistant</td>
                    <td className="p-2 text-center">70%</td>
                    <td className="p-2 text-center">60%</td>
                    <td className="p-2 text-center">5%</td>
                    <td className="p-2 text-muted-foreground">Highly repetitive, structured data tasks. Highest time savings, strong quality gains, minimal revenue impact.</td>
                  </tr>
                  <tr className="hover-elevate">
                    <td className="p-2 font-medium">Accounts Payable/Receivable Clerk</td>
                    <td className="p-2 text-center">65%</td>
                    <td className="p-2 text-center">65%</td>
                    <td className="p-2 text-center">5%</td>
                    <td className="p-2 text-muted-foreground">Invoice processing, payment handling. AI eliminates financial errors and accelerates cycles.</td>
                  </tr>
                  <tr className="hover-elevate">
                    <td className="p-2 font-medium">Customer Support Agent (Tier 1)</td>
                    <td className="p-2 text-center">65%</td>
                    <td className="p-2 text-center">40%</td>
                    <td className="p-2 text-center">25%</td>
                    <td className="p-2 text-muted-foreground">First-line support, FAQ handling. Frees capacity for retention and upsells.</td>
                  </tr>
                  <tr className="hover-elevate">
                    <td className="p-2 font-medium">Payroll Specialist / Coordinator</td>
                    <td className="p-2 text-center">60%</td>
                    <td className="p-2 text-center">65%</td>
                    <td className="p-2 text-center">5%</td>
                    <td className="p-2 text-muted-foreground">Payroll processing, compliance checks. AI ensures accurate, on-time payments.</td>
                  </tr>
                  <tr className="hover-elevate">
                    <td className="p-2 font-medium">Sales Operations / CRM Administrator</td>
                    <td className="p-2 text-center">60%</td>
                    <td className="p-2 text-center">50%</td>
                    <td className="p-2 text-center">50%</td>
                    <td className="p-2 text-muted-foreground">Pipeline management, CRM hygiene. Directly accelerates sales velocity and win rates.</td>
                  </tr>
                  <tr className="hover-elevate">
                    <td className="p-2 font-medium">IT Support / Help Desk (Tier 1-2)</td>
                    <td className="p-2 text-center">60%</td>
                    <td className="p-2 text-center">45%</td>
                    <td className="p-2 text-center">10%</td>
                    <td className="p-2 text-muted-foreground">Troubleshooting, ticket routing. AI diagnostics improve first-contact resolution.</td>
                  </tr>
                  <tr className="hover-elevate">
                    <td className="p-2 font-medium">Procurement / Purchasing Agent</td>
                    <td className="p-2 text-center">55%</td>
                    <td className="p-2 text-center">55%</td>
                    <td className="p-2 text-center">15%</td>
                    <td className="p-2 text-muted-foreground">Vendor management, PO processing. AI reduces COGS through better sourcing decisions.</td>
                  </tr>
                  <tr className="hover-elevate">
                    <td className="p-2 font-medium">HR Coordinator / Generalist</td>
                    <td className="p-2 text-center">55%</td>
                    <td className="p-2 text-center">35%</td>
                    <td className="p-2 text-center">10%</td>
                    <td className="p-2 text-muted-foreground">Benefits admin, onboarding workflows. Indirect uplift through manager time reclaim.</td>
                  </tr>
                  <tr className="hover-elevate">
                    <td className="p-2 font-medium">Marketing Operations Specialist</td>
                    <td className="p-2 text-center">55%</td>
                    <td className="p-2 text-center">40%</td>
                    <td className="p-2 text-center">30%</td>
                    <td className="p-2 text-muted-foreground">Campaign execution, list management. AI improves targeting and lead quality.</td>
                  </tr>
                  <tr className="hover-elevate">
                    <td className="p-2 font-medium">Operations Coordinator / Analyst</td>
                    <td className="p-2 text-center">50%</td>
                    <td className="p-2 text-center">50%</td>
                    <td className="p-2 text-center">20%</td>
                    <td className="p-2 text-muted-foreground">Process optimization, reporting. AI reduces operational friction and delays.</td>
                  </tr>
                  <tr className="hover-elevate">
                    <td className="p-2 font-medium">Executive Assistant / Office Manager</td>
                    <td className="p-2 text-center">50%</td>
                    <td className="p-2 text-center">40%</td>
                    <td className="p-2 text-center">10%</td>
                    <td className="p-2 text-muted-foreground">Scheduling, coordination, admin support. Frees executive time for strategy.</td>
                  </tr>
                  <tr className="hover-elevate">
                    <td className="p-2 font-medium">Financial Analyst / FP&A</td>
                    <td className="p-2 text-center">45%</td>
                    <td className="p-2 text-center">55%</td>
                    <td className="p-2 text-center">35%</td>
                    <td className="p-2 text-muted-foreground">Financial modeling, forecasting. AI accelerates insights for strategic decisions.</td>
                  </tr>
                  <tr className="hover-elevate">
                    <td className="p-2 font-medium">Compliance / QA / Audit Specialist</td>
                    <td className="p-2 text-center">45%</td>
                    <td className="p-2 text-center">70%</td>
                    <td className="p-2 text-center">5%</td>
                    <td className="p-2 text-muted-foreground">Regulatory checks, QA testing. AI never tires, ensuring 100% rule coverage.</td>
                  </tr>
                  <tr className="hover-elevate">
                    <td className="p-2 font-medium">Customer Success Manager</td>
                    <td className="p-2 text-center">40%</td>
                    <td className="p-2 text-center">35%</td>
                    <td className="p-2 text-center">45%</td>
                    <td className="p-2 text-muted-foreground">Account management, renewal tracking. Maximizes NRR and enables expansion revenue.</td>
                  </tr>
                  <tr className="hover-elevate">
                    <td className="p-2 font-medium">Legal / Contract Administrator</td>
                    <td className="p-2 text-center">40%</td>
                    <td className="p-2 text-center">50%</td>
                    <td className="p-2 text-center">5%</td>
                    <td className="p-2 text-muted-foreground">Contract review, compliance docs. AI catches clause inconsistencies and risks.</td>
                  </tr>
                  <tr className="hover-elevate">
                    <td className="p-2 font-medium">Other (specify in comments)</td>
                    <td className="p-2 text-center">30%</td>
                    <td className="p-2 text-center">20%</td>
                    <td className="p-2 text-center">0%</td>
                    <td className="p-2 text-muted-foreground">Conservative baseline for unspecified roles. Actual benefits depend on characteristics you describe.</td>
                  </tr>
                </tbody>
              </table>
            </div>

            <div className="bg-amber-50 dark:bg-amber-950/20 p-4 rounded-md border border-amber-200 dark:border-amber-900 mt-4">
              <p className="text-sm font-semibold mb-2">📊 Key Insights from Role-Based Analysis</p>
              <ul className="text-xs text-muted-foreground space-y-1">
                <li>• <strong>Time Savings</strong> peaks for highly repetitive, structured roles (Data Entry, AP/AR) where AI eliminates manual effort</li>
                <li>• <strong>Quality Impact</strong> peaks for precision-critical roles (Compliance, Payroll) where AI's consistency prevents costly errors</li>
                <li>• <strong>Revenue Uplift</strong> peaks for customer-facing roles (Sales Ops, Customer Success) where AI directly accelerates revenue cycles</li>
                <li>• Base percentages are conservative starting points; actual results vary based on implementation, adoption, and process specifics</li>
              </ul>
            </div>
          </div>

          </CardContent>
      </Card>
      {/* 6. AI Time Saved Rubric */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Zap className="h-5 w-5 text-blue-600" />
            AI Time Saved Rubric: Evaluation Criteria
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <p className="text-sm text-muted-foreground">
            After selecting your role type in the "Understanding Role-Based Classification" section above, the calculator refines 
            that baseline percentage using three additional factors that significantly impact automation success.
          </p>
          
          <div className="space-y-3">
            <h4 className="font-semibold mb-3">Evaluation Questions</h4>
            <div className="space-y-3">
              <div>
                <Badge variant="secondary" className="text-xs">Question 2</Badge>
                <p className="text-sm mt-1"><strong>Complexity:</strong> How complex are the decision-making rules?</p>
                <p className="text-xs text-muted-foreground">
                  Rationale: Simple, rule-based processes automate more easily than complex judgment calls
                </p>
                <ul className="text-xs text-muted-foreground mt-2 space-y-1">
                  <li>• <strong>Simple (1.3x):</strong> Clear rules, binary decisions - minimal judgment required</li>
                  <li>• <strong>Moderate (1.0x):</strong> Some exceptions and edge cases - structured decision-making</li>
                  <li>• <strong>Complex (0.7x):</strong> Many variables and nuanced judgment - significant human expertise needed</li>
                </ul>
              </div>
              <div>
                <Badge variant="secondary" className="text-xs">Question 3</Badge>
                <p className="text-sm mt-1"><strong>Repetition Frequency:</strong> How often is this process repeated?</p>
                <p className="text-xs text-muted-foreground">
                  Rationale: Higher frequency processes justify automation investment and see faster adoption
                </p>
                <ul className="text-xs text-muted-foreground mt-2 space-y-1">
                  <li>• <strong>Daily (1.2x):</strong> Multiple times per day - high volume justifies automation</li>
                  <li>• <strong>Weekly (1.0x):</strong> Several times per week - moderate automation benefit</li>
                  <li>• <strong>Monthly (0.8x):</strong> Few times per month - lower automation ROI</li>
                </ul>
              </div>
              <div>
                <Badge variant="secondary" className="text-xs">Question 4</Badge>
                <p className="text-sm mt-1"><strong>Data Structure:</strong> How structured and standardized are inputs?</p>
                <p className="text-xs text-muted-foreground">
                  Rationale: Structured data with clear formats automates more successfully than unstructured inputs
                </p>
                <ul className="text-xs text-muted-foreground mt-2 space-y-1">
                  <li>• <strong>Highly Structured (1.3x):</strong> Standardized formats, consistent fields - ideal for automation</li>
                  <li>• <strong>Semi-Structured (1.0x):</strong> Some variation but predictable patterns - manageable</li>
                  <li>• <strong>Unstructured (0.7x):</strong> Free-form inputs, high variability - challenging to automate</li>
                </ul>
              </div>
            </div>
          </div>

          <Separator />

          <div className="bg-blue-50 dark:bg-blue-950/20 p-4 rounded-md border border-blue-200 dark:border-blue-900">
            <p className="text-sm font-semibold mb-1">📊 Role-Based Classifications</p>
            <p className="text-xs text-muted-foreground">
              For complete details on all 15 roles with base percentages and descriptions, 
              see the <strong>"Understanding Role-Based Classification"</strong> section above.
            </p>
          </div>

          <div>
            <h4 className="font-semibold mb-2">Scoring Logic: Multiplicative Calculation</h4>
            <div className="bg-muted p-4 rounded-md">
              <p className="text-sm font-mono mb-3">
                Time Saved % = Process Base % × Complexity × Repetition × Structure (Category-Capped)
              </p>
              <p className="text-xs text-muted-foreground mb-3">
                <strong>Why multiplicative, not averaging?</strong> Automation challenges compound. A complex task 
                (0.7x) done monthly (0.8x) with unstructured data (0.7x) creates 0.7 × 0.8 × 0.7 = 39% efficiency - 
                reflecting the reality that multiple friction points dramatically reduce automation potential.
              </p>
              <div className="space-y-2">
                <div className="bg-background p-3 rounded-md border">
                  <p className="text-sm font-semibold mb-1">Example: Optimistic Scenario (Data Entry, 60% base)</p>
                  <p className="text-xs font-mono">
                    60% × Simple (1.3x) × Daily (1.2x) × Highly Structured (1.3x) = 122% → Capped at 85% (category max)
                  </p>
                  <p className="text-xs text-muted-foreground mt-1">
                    Ideal automation conditions. Simple, repetitive, structured data entry tasks achieve maximum time savings.
                  </p>
                </div>
                <div className="bg-background p-3 rounded-md border">
                  <p className="text-sm font-semibold mb-1">Example: Baseline Scenario (Data Entry, 60% base)</p>
                  <p className="text-xs font-mono">
                    60% × Moderate (1.0x) × Weekly (1.0x) × Semi-Structured (1.0x) = 60%
                  </p>
                  <p className="text-xs text-muted-foreground mt-1">
                    Standard automation with typical characteristics. Achieves the baseline time savings percentage.
                  </p>
                </div>
                <div className="bg-background p-3 rounded-md border">
                  <p className="text-sm font-semibold mb-1">Example: Challenging Scenario (Data Entry, 60% base)</p>
                  <p className="text-xs font-mono">
                    60% × Complex (0.7x) × Monthly (0.8x) × Unstructured (0.7x) = 24% → Stays at 30% (category min)
                  </p>
                  <p className="text-xs text-muted-foreground mt-1">
                    Multiple constraints compound. Complex, infrequent tasks with unstructured data yield lower automation value.
                  </p>
                </div>
              </div>
              <p className="text-xs text-muted-foreground mt-3">
                <strong>Category-specific capping:</strong> Each role has researched min/max ranges. 
                Results are automatically capped within these bounds to ensure realistic, credible estimates.
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
      {/* 7. Quality Impact Rubric */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Shield className="h-5 w-5 text-purple-600" />
            Quality Impact Rubric: Evaluation Criteria
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <p className="text-sm text-muted-foreground">
            After selecting your role type in the "Understanding Role-Based Classification" section above, the Quality Impact 
            rubric refines that baseline percentage using five additional factors that determine how effectively AI can improve 
            quality. These factors assess error patterns, root causes, detection timing, standardization levels, and AI suitability.
          </p>
          
          <div className="space-y-3">
            <h4 className="font-semibold mb-3">Evaluation Questions</h4>
            <div className="space-y-3">
              <div>
                <Badge variant="secondary" className="text-xs">Question 2</Badge>
                <p className="text-sm mt-1"><strong>Error Frequency:</strong> How often do errors occur in this process?</p>
                <p className="text-xs text-muted-foreground">
                  Rationale: Higher error rates provide more opportunity for AI-driven quality improvement
                </p>
                <ul className="text-xs text-muted-foreground mt-2 space-y-1">
                  <li>• <strong>Very Frequent (&gt;30%) (1.3x):</strong> Errors happen constantly - high improvement potential</li>
                  <li>• <strong>Frequent (15-30%) (1.15x):</strong> Regular errors - significant room for improvement</li>
                  <li>• <strong>Occasional (5-15%) (1.0x):</strong> Moderate error rate - typical improvement opportunity</li>
                  <li>• <strong>Rare (&lt;5%) (0.8x):</strong> Infrequent errors - limited improvement potential</li>
                </ul>
              </div>
              <div>
                <Badge variant="secondary" className="text-xs">Question 3</Badge>
                <p className="text-sm mt-1"><strong>Error Root Cause:</strong> What primarily causes errors in this process?</p>
                <p className="text-xs text-muted-foreground">
                  Rationale: AI excels at preventing human repetitive errors but struggles with communication breakdowns
                </p>
                <ul className="text-xs text-muted-foreground mt-2 space-y-1">
                  <li>• <strong>Manual/Repetitive Work (1.3x):</strong> Fatigue, typos, missed steps - ideal for AI prevention</li>
                  <li>• <strong>Information Gaps (1.15x):</strong> Missing or unclear data - AI can enforce completeness</li>
                  <li>• <strong>Inconsistent Standards (1.15x):</strong> Different interpretations - AI ensures uniformity</li>
                  <li>• <strong>Process Complexity (0.8x):</strong> Inherent difficulty - AI has limited impact</li>
                  <li>• <strong>Communication Breakdowns (1.0x):</strong> Coordination issues - moderate AI benefit</li>
                </ul>
              </div>
              <div>
                <Badge variant="secondary" className="text-xs">Question 4</Badge>
                <p className="text-sm mt-1"><strong>Detection Timing:</strong> When are errors typically discovered?</p>
                <p className="text-xs text-muted-foreground">
                  Rationale: Late-detected errors have higher impact and benefit more from AI prevention
                </p>
                <ul className="text-xs text-muted-foreground mt-2 space-y-1">
                  <li>• <strong>Post-Delivery (1.3x):</strong> Customer finds it - highest impact, maximum AI value</li>
                  <li>• <strong>End of Process (1.15x):</strong> Final review catches it - costly rework prevented</li>
                  <li>• <strong>Mid-Process (1.0x):</strong> Caught during execution - moderate impact</li>
                  <li>• <strong>Early Stage (0.8x):</strong> Detected immediately - minimal damage, lower AI value</li>
                </ul>
              </div>
              <div>
                <Badge variant="secondary" className="text-xs">Question 5</Badge>
                <p className="text-sm mt-1"><strong>Process Standardization:</strong> How standardized is this process?</p>
                <p className="text-xs text-muted-foreground">
                  Rationale: Well-documented processes with clear standards enable better AI quality control
                </p>
                <ul className="text-xs text-muted-foreground mt-2 space-y-1">
                  <li>• <strong>Strict Standards/Compliance (1.3x):</strong> Mandatory compliance rules - AI excels at enforcement</li>
                  <li>• <strong>Documented Process (1.15x):</strong> Clear SOPs with some flexibility - good AI fit</li>
                  <li>• <strong>General Guidelines (1.0x):</strong> Some variation expected - moderate AI benefit</li>
                  <li>• <strong>Highly Variable/Ad-hoc (0.8x):</strong> Case-by-case approaches - limited AI applicability</li>
                </ul>
              </div>
              <div>
                <Badge variant="secondary" className="text-xs">Question 6</Badge>
                <p className="text-sm mt-1"><strong>AI Suitability:</strong> What type of quality checking does this process require?</p>
                <p className="text-xs text-muted-foreground">
                  Rationale: Rule-based checking is ideal for AI; subjective judgment less so
                </p>
                <ul className="text-xs text-muted-foreground mt-2 space-y-1">
                  <li>• <strong>Clear Rules-Based Validation (1.3x):</strong> Binary pass/fail checks - perfect for AI</li>
                  <li>• <strong>Pattern Recognition (1.15x):</strong> Learn from examples - strong AI capability</li>
                  <li>• <strong>Contextual Judgment (1.0x):</strong> Needs some interpretation - moderate AI fit</li>
                  <li>• <strong>Highly Subjective/Creative (0.8x):</strong> Aesthetic or strategic assessment - weak AI fit</li>
                </ul>
              </div>
            </div>
          </div>

          <Separator />

          <div className="bg-purple-50 dark:bg-purple-950/20 p-4 rounded-md border border-purple-200 dark:border-purple-900">
            <p className="text-sm font-semibold mb-1">📊 Role-Based Classifications</p>
            <p className="text-xs text-muted-foreground">
              For complete details on all 15 roles with base percentages and descriptions, 
              see the <strong>"Understanding Role-Based Classification"</strong> section above.
            </p>
          </div>

          <div>
            <h4 className="font-semibold mb-2">Scoring Logic: Averaged Multiplier Calculation</h4>
            <div className="bg-muted p-4 rounded-md">
              <p className="text-sm font-mono mb-3">
                Quality Improvement % = Process Base % × Average(5 Multipliers) (Capped 5-95%)
              </p>
              <p className="text-xs text-muted-foreground mb-3">
                <strong>Why averaged, not multiplicative?</strong> Quality improvement requires multiple factors to align, 
                but extreme scenarios in one area shouldn't dominate. Averaging 5 factors (error frequency, root cause, 
                detection timing, standardization, AI suitability) provides a balanced assessment while still reflecting 
                that more favorable conditions (average 1.3x) yield higher improvements than challenging ones (average 0.8x).
              </p>
              <div className="space-y-2">
                <div className="bg-background p-3 rounded-md border">
                  <p className="text-sm font-semibold mb-1">Example: Optimistic Scenario (Data Validation, 70% base)</p>
                  <p className="text-xs font-mono">
                    70% × Avg(Very Frequent 1.3x, Manual 1.3x, Post-Delivery 1.3x, Strict Standards 1.3x, Rule-Based 1.3x) = 70% × 1.3 = 91%
                  </p>
                  <p className="text-xs text-muted-foreground mt-1">
                    All factors favorable. Frequent errors from manual work, caught late, in standardized processes with rule-based validation - ideal for AI quality improvement.
                  </p>
                </div>
                <div className="bg-background p-3 rounded-md border">
                  <p className="text-sm font-semibold mb-1">Example: Baseline Scenario (Data Validation, 70% base)</p>
                  <p className="text-xs font-mono">
                    70% × Avg(Occasional 1.0x, Info Gaps 1.15x, Mid-Process 1.0x, Guidelines 1.0x, Contextual 1.0x) = 70% × 1.03 = 72%
                  </p>
                  <p className="text-xs text-muted-foreground mt-1">
                    Mixed conditions with one slightly favorable factor. Achieves near-baseline quality improvement with modest gains.
                  </p>
                </div>
                <div className="bg-background p-3 rounded-md border">
                  <p className="text-sm font-semibold mb-1">Example: Challenging Scenario (Data Validation, 70% base)</p>
                  <p className="text-xs font-mono">
                    70% × Avg(Rare 0.8x, Complexity 0.8x, Early 0.8x, Variable 0.8x, Subjective 0.8x) = 70% × 0.8 = 56%
                  </p>
                  <p className="text-xs text-muted-foreground mt-1">
                    Multiple unfavorable factors. Infrequent errors from complexity, detected early, in variable processes requiring judgment - limited AI quality benefit.
                  </p>
                </div>
              </div>
              <p className="text-xs text-muted-foreground mt-3">
                <strong>Universal capping at 5-95%:</strong> Unlike Time Savings, Quality Impact uses fixed global bounds 
                to ensure realistic estimates across all roles.
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
      {/* 8. Revenue Uplift Rubric */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <DollarSign className="h-5 w-5 text-green-600" />
            Revenue Uplift Rubric: Evaluation Criteria
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <p className="text-sm text-muted-foreground">
            After selecting your role type in the "Understanding Role-Based Classification" section above, the Revenue Uplift 
            rubric refines that baseline percentage using two critical business factors: current capacity constraints and 
            the structure of your revenue process. This conservative approach acknowledges that not all time saved translates 
            to revenue - it depends on available demand and clear paths to revenue generation.
          </p>
          
          <div className="space-y-3">
            <h4 className="font-semibold mb-3">Evaluation Questions</h4>
            <div className="space-y-3">
              <div>
                <Badge variant="secondary" className="text-xs">Question 2</Badge>
                <p className="text-sm mt-1"><strong>Capacity vs. Demand:</strong> What is the relationship between current capacity and available opportunities?</p>
                <p className="text-xs text-muted-foreground">
                  Rationale: Freed time only converts to revenue when teams are stretched thin AND there are opportunities to pursue
                </p>
                <ul className="text-xs text-muted-foreground mt-2 space-y-1">
                  <li>• <strong>High Demand, At/Above Capacity (1.4x):</strong> Team is maxed out with clear unmet demand - high revenue conversion</li>
                  <li>• <strong>Strong Pipeline, Near Capacity (1.2x):</strong> Visible opportunities, team approaching limits - good conversion potential</li>
                  <li>• <strong>Moderate Opportunities/Capacity (0.9x):</strong> Some slack, some opportunities - limited conversion</li>
                  <li>• <strong>Limited Opportunities or Low Utilization (0.4x):</strong> Excess capacity or weak pipeline - minimal revenue impact</li>
                </ul>
              </div>
              <div>
                <Badge variant="secondary" className="text-xs">Question 3</Badge>
                <p className="text-sm mt-1"><strong>Revenue Process Structure:</strong> How does more time translate to more revenue?</p>
                <p className="text-xs text-muted-foreground">
                  Rationale: Some revenue processes scale linearly with time (service delivery), others face complexity constraints (long sales cycles)
                </p>
                <ul className="text-xs text-muted-foreground mt-2 space-y-1">
                  <li>• <strong>Direct & Predictable (1.2x):</strong> More time = more sales/delivery immediately - linear relationship</li>
                  <li>• <strong>Somewhat Predictable (1.0x):</strong> Time helps but other factors matter - moderate relationship</li>
                  <li>• <strong>Indirect/Complex (0.7x):</strong> Long cycles, many dependencies - weak time-revenue link</li>
                  <li>• <strong>Limited by Other Factors (0.4x):</strong> Constrained by market, regulations, or resources - minimal time impact</li>
                </ul>
              </div>
            </div>
          </div>

          <Separator />

          <div>
            <h4 className="font-semibold mb-2">Scoring Logic: Multiplicative Calculation with Conservative Cap</h4>
            <div className="bg-muted p-4 rounded-md">
              <p className="text-sm font-mono mb-3">
                Revenue Reallocation % = Role Base % × Capacity/Demand × Process Structure (Hard Cap: 60%)
              </p>
              <p className="text-xs text-muted-foreground mb-3">
                <strong>Why multiplicative, not averaging?</strong> Revenue conversion requires BOTH available capacity AND 
                a direct path to revenue. A sales team at capacity (1.4x) but with complex sales cycles (0.7x) creates 
                1.4 × 0.7 = 98% of baseline - reflecting that capacity alone isn't enough without a clear revenue path.
              </p>
              <div className="space-y-2">
                <div className="bg-background p-3 rounded-md border">
                  <p className="text-sm font-semibold mb-1">Example: Optimistic Scenario (Sales Operations, 60% base)</p>
                  <p className="text-xs font-mono">
                    60% × High Demand (1.4x) × Direct Predictable (1.2x) = 101% → Capped at 60% (conservative limit)
                  </p>
                  <p className="text-xs text-muted-foreground mt-1">
                    Perfect conditions would theoretically exceed baseline, but the 60% hard cap ensures conservative projections. Even optimal scenarios acknowledge friction and non-revenue activities.
                  </p>
                </div>
                <div className="bg-background p-3 rounded-md border">
                  <p className="text-sm font-semibold mb-1">Example: Baseline Scenario (Sales Operations, 60% base)</p>
                  <p className="text-xs font-mono">
                    60% × Strong Pipeline (1.2x) × Somewhat Predictable (1.0x) = 72% → Capped at 60%
                  </p>
                  <p className="text-xs text-muted-foreground mt-1">
                    Good capacity situation with moderate revenue path clarity. Result still hits the conservative cap.
                  </p>
                </div>
                <div className="bg-background p-3 rounded-md border">
                  <p className="text-sm font-semibold mb-1">Example: Challenging Scenario (Sales Operations, 60% base)</p>
                  <p className="text-xs font-mono">
                    60% × Limited Opportunities (0.4x) × Limited by Factors (0.4x) = 10%
                  </p>
                  <p className="text-xs text-muted-foreground mt-1">
                    Low demand or constrained revenue process. Multiple limitations compound to dramatically reduce time-to-revenue conversion potential.
                  </p>
                </div>
              </div>
              <p className="text-xs text-muted-foreground mt-3">
                <strong>Hard cap at 60%:</strong> This is the most conservative module. Even Sales Operations roles in perfect 
                conditions cannot convert 100% of freed time to revenue - there are always meetings, coordination, and non-revenue 
                activities that consume time.
              </p>
            </div>
          </div>

          <div className="bg-yellow-50 dark:bg-yellow-950/20 p-4 rounded-md border border-yellow-200 dark:border-yellow-900">
            <p className="text-sm font-semibold mb-2">⚠️ Use Revenue Uplift Conservatively</p>
            <p className="text-xs text-muted-foreground">
              Revenue uplift should only be enabled when there is clear evidence that saved time will be redirected 
              to revenue-generating activities. This is typically only applicable for direct revenue roles at or near 
              capacity with existing unmet demand. When in doubt, exclude this module to maintain conservative estimates.
            </p>
          </div>
        </CardContent>
      </Card>
      {/* 9. Ramp-Up Efficiency Rubric (NEW SECTION) */}
      <Card className="border-primary/20 bg-primary/5">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <TrendingUp className="h-5 w-5 text-primary" />
            Ramp-Up Efficiency Rubric: Evaluation Criteria
          </CardTitle>
          <CardDescription>
            Assessing implementation smoothness and adoption speed during Year 1 ramp-up period
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <p className="text-sm text-muted-foreground">
            The Ramp-Up Efficiency rubric evaluates how smoothly your AI implementation will roll out during Year 1. 
            Unlike other rubrics that estimate benefit percentages, this rubric calculates an <strong>efficiency multiplier</strong> 
            (20% to 150%) that adjusts the base ramp-up factor based on implementation complexity, user digital comfort, 
            rollout approach, and support structure. This multiplier only affects Year 1 ROI calculations, refining the 
            adoption timeline to reflect realistic implementation scenarios.
          </p>

          <div className="bg-yellow-50 dark:bg-yellow-950/20 p-4 rounded-md border border-yellow-200 dark:border-yellow-900">
            <p className="text-sm font-semibold mb-2">🎯 Year 1 Only - No Impact on Years 2-5</p>
            <p className="text-xs text-muted-foreground">
              The Ramp-Up Efficiency multiplier applies exclusively to Year 1 benefit realization. Years 2-5 always 
              assume 100% full run-rate benefits (no ramp-up adjustment). This models the reality that implementation 
              friction is temporary - once systems are stable and users are trained, processes reach full efficiency.
            </p>
          </div>

          <div className="space-y-3">
            <h4 className="font-semibold mb-3">Evaluation Questions</h4>
            <div className="space-y-3">
              <div>
                <Badge variant="secondary" className="text-xs">Question 1</Badge>
                <p className="text-sm mt-1"><strong>Implementation Complexity:</strong> How complex is this AI implementation?</p>
                <p className="text-xs text-muted-foreground">
                  Rationale: Simple automations of existing digital processes roll out faster than enterprise-wide transformations
                </p>
                <ul className="text-xs text-muted-foreground mt-2 space-y-1">
                  <li>• <strong>Low (1.1x):</strong> Simple automation of existing digital process - minimal workflow changes</li>
                  <li>• <strong>Moderate (1.0x):</strong> Some process redesign and integration required - manageable change</li>
                  <li>• <strong>High (0.85x):</strong> Major workflow transformation across multiple systems - significant adaptation needed</li>
                  <li>• <strong>Very High (0.7x):</strong> Enterprise-wide transformation - extensive change management required</li>
                </ul>
              </div>
              <div>
                <Badge variant="secondary" className="text-xs">Question 2</Badge>
                <p className="text-sm mt-1"><strong>User Digital Comfort:</strong> How comfortable are users with adopting new digital tools?</p>
                <p className="text-xs text-muted-foreground">
                  Rationale: Tech-comfortable teams adopt AI faster; technology-averse teams need more support and time
                </p>
                <ul className="text-xs text-muted-foreground mt-2 space-y-1">
                  <li>• <strong>Very Uncomfortable (0.7x):</strong> Prefer traditional methods - significant resistance to new tools</li>
                  <li>• <strong>Somewhat Uncomfortable (0.85x):</strong> Need significant support - hesitant but willing with guidance</li>
                  <li>• <strong>Neutral (1.0x):</strong> Can adapt with guidance - neither enthusiastic nor resistant</li>
                  <li>• <strong>Comfortable (1.1x):</strong> Quick to learn - embrace new tools readily</li>
                  <li>• <strong>Very Comfortable (1.2x):</strong> Early adopters - actively seek out efficiency improvements</li>
                </ul>
              </div>
              <div>
                <Badge variant="secondary" className="text-xs">Question 3</Badge>
                <p className="text-sm mt-1"><strong>Rollout Strategy:</strong> What is your implementation rollout approach?</p>
                <p className="text-xs text-muted-foreground">
                  Rationale: Phased rollouts with pilot testing reduce risk and accelerate adoption through lessons learned
                </p>
                <ul className="text-xs text-muted-foreground mt-2 space-y-1">
                  <li>• <strong>Pilot First (1.1x):</strong> Test with small group, then gradual rollout with lessons learned - minimizes risk</li>
                  <li>• <strong>Phased (1.0x):</strong> Gradual rollout across departments or teams - balanced approach</li>
                  <li>• <strong>Parallel (0.9x):</strong> Run old and new processes side-by-side - ensures continuity but slows adoption</li>
                  <li>• <strong>Big Bang (0.8x):</strong> Switch all users/processes at once - high risk, potential disruption</li>
                </ul>
              </div>
              <div>
                <Badge variant="secondary" className="text-xs">Question 4</Badge>
                <p className="text-sm mt-1"><strong>Support Structure:</strong> What support is in place for implementation?</p>
                <p className="text-xs text-muted-foreground">
                  Rationale: Dedicated change teams, executive sponsorship, and clear governance accelerate successful adoption
                </p>
                <ul className="text-xs text-muted-foreground mt-2 space-y-1">
                  <li>• <strong>Strong (1.1x):</strong> Dedicated change team, executive sponsor, clear governance - full organizational support</li>
                  <li>• <strong>Basic (0.95x):</strong> Some support resources, ad-hoc governance - limited but functional support</li>
                  <li>• <strong>Minimal (0.8x):</strong> Limited support, mostly self-service/DIY - users largely on their own</li>
                </ul>
              </div>
            </div>
          </div>

          <Separator />

          <div>
            <h4 className="font-semibold mb-2">Scoring Logic: Multiplicative Efficiency Calculation</h4>
            <div className="bg-muted p-4 rounded-md">
              <p className="text-sm font-mono mb-3">
                Efficiency % = 100% × Complexity × Digital Comfort × Rollout × Support (Capped 20-150%)
              </p>
              <p className="text-xs text-muted-foreground mb-3">
                <strong>Why multiplicative, not averaging?</strong> Implementation challenges compound. A complex project 
                (0.7x) with tech-averse users (0.7x) and minimal support (0.8x) creates 0.7 × 0.7 × 0.8 = 39% efficiency - 
                reflecting the reality that multiple friction points dramatically slow adoption.
              </p>
              <div className="space-y-2">
                <div className="bg-background p-3 rounded-md border">
                  <p className="text-sm font-semibold mb-1">Example: Optimistic Scenario</p>
                  <p className="text-xs font-mono">
                    Low complexity (1.1x) × Very comfortable users (1.2x) × Pilot-first (1.1x) × Strong support (1.1x) = 160% → Capped at 150%
                  </p>
                  <p className="text-xs text-muted-foreground mt-1">
                    Ideal conditions enable faster-than-planned adoption. Benefits realized 50% faster during ramp-up period.
                  </p>
                </div>
                <div className="bg-background p-3 rounded-md border">
                  <p className="text-sm font-semibold mb-1">Example: Baseline Scenario</p>
                  <p className="text-xs font-mono">
                    Moderate complexity (1.0x) × Neutral users (1.0x) × Phased rollout (1.0x) × Basic support (0.95x) = 95%
                  </p>
                  <p className="text-xs text-muted-foreground mt-1">
                    Standard implementation with typical challenges. Adoption slightly slower than planned.
                  </p>
                </div>
                <div className="bg-background p-3 rounded-md border">
                  <p className="text-sm font-semibold mb-1">Example: Challenging Scenario</p>
                  <p className="text-xs font-mono">
                    High complexity (0.85x) × Somewhat uncomfortable (0.85x) × Big Bang (0.8x) × Minimal support (0.8x) = 46%
                  </p>
                  <p className="text-xs text-muted-foreground mt-1">
                    Multiple friction points compound. Benefits realized at less than half the expected speed during Year 1.
                  </p>
                </div>
              </div>
            </div>
          </div>

          <div>
            <h4 className="font-semibold mb-2">How Ramp-Up Efficiency Affects Year 1 ROI</h4>
            <p className="text-sm text-muted-foreground mb-3">
              The efficiency multiplier adjusts the base ramp-up factor to reflect implementation reality:
            </p>
            <div className="bg-background p-4 rounded-md border">
              <p className="text-sm font-mono mb-2">
                Year 1 Effective Benefits = Annual Benefits × Base Ramp Factor × (Efficiency % ÷ 100)
              </p>
              <div className="text-xs text-muted-foreground space-y-2">
                <p>
                  <strong>Example with 6-month implementation (75% base ramp factor):</strong>
                </p>
                <ul className="space-y-1 ml-4">
                  <li>• Annual benefits: $100,000</li>
                  <li>• Base ramp factor (6 months): 75%</li>
                  <li>• Efficiency (challenging scenario): 46%</li>
                  <li>• <strong>Year 1 benefits:</strong> $100,000 × 0.75 × 0.46 = $34,500</li>
                </ul>
                <p className="mt-2">
                  Compare this to optimistic scenario (150% efficiency): $100,000 × 0.75 × 1.50 = $112,500 Year 1 benefits. 
                  The 104-point efficiency swing ($112,500 vs $34,500) dramatically affects Year 1 ROI and payback period.
                </p>
              </div>
            </div>
          </div>

          <div className="bg-blue-50 dark:bg-blue-950/20 p-4 rounded-md border border-blue-200 dark:border-blue-900">
            <p className="text-sm font-semibold mb-2">💡 Strategic Implications</p>
            <p className="text-xs text-muted-foreground mb-2">
              The Ramp-Up Efficiency rubric helps you understand that <strong>implementation approach matters as much as 
              technology selection</strong>. Even the best AI solution will underdeliver if deployed with a Big Bang approach 
              to technology-averse users without proper support.
            </p>
            <p className="text-xs text-muted-foreground">
              <strong>Recommendation:</strong> Use this rubric to identify implementation risks early and justify investment 
              in change management, pilot programs, and user training - which can dramatically improve Year 1 ROI.
            </p>
          </div>
        </CardContent>
      </Card>
      {/* 10. Complete Mathematical Flow: From Inputs to Final ROI (MERGED SECTION) */}
      <Card className="border-primary/30">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Target className="h-5 w-5 text-primary" />
            Complete Mathematical Flow: From Inputs to Final ROI
          </CardTitle>
          <CardDescription>
            Comprehensive explanation of calculations, scenario multipliers, and granular business metrics
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <p className="text-sm text-muted-foreground">
            This section provides the complete mathematical journey from your inputs to final ROI metrics. It combines 
            detailed formulas, scenario multiplier logic, and granular business impact calculations into one comprehensive 
            reference. Follow along to understand exactly how the calculator transforms your inputs into defensible ROI projections.
          </p>

          <Separator />

          {/* Part A: Scenario Multipliers & How They Interact */}
          <div className="space-y-4">
            <h3 className="text-lg font-semibold flex items-center gap-2">
              <TrendingUp className="h-5 w-5 text-primary" />
              Part A: Scenario Multipliers & How They Interact with Calculations
            </h3>
            
            <p className="text-sm text-muted-foreground">
              The ROI Calculator uses a <strong>"double-layer conservatism"</strong> system to ensure credible, 
              defensible estimates. First, rubrics provide conservative, role-based percentages. Then, scenario 
              multipliers adjust these values based on implementation reality and organizational factors.
            </p>

            <div>
              <h4 className="font-semibold mb-3">Five Scenario Multiplier Types</h4>
              <p className="text-xs text-muted-foreground mb-4">
                Each benefit and cost category has its own scenario-based multipliers that reflect real-world implementation outcomes
              </p>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="bg-muted p-4 rounded-md">
                  <div className="flex items-center gap-2 mb-2">
                    <Badge variant="secondary" className="text-xs">Benefit Multiplier 1</Badge>
                  </div>
                  <h5 className="font-semibold mb-2">Time Savings Multiplier</h5>
                  <div className="text-xs space-y-1">
                    <div className="flex justify-between">
                      <span>• Best Case:</span>
                      <strong>115%</strong>
                    </div>
                    <div className="flex justify-between">
                      <span>• Base Case:</span>
                      <strong>100%</strong>
                    </div>
                    <div className="flex justify-between">
                      <span>• Conservative:</span>
                      <strong>70%</strong>
                    </div>
                    <div className="flex justify-between">
                      <span>• Worst Case:</span>
                      <strong>40%</strong>
                    </div>
                  </div>
                  <p className="text-xs text-muted-foreground mt-2">
                    <strong>Why this matters:</strong> Reflects actual time saved after accounting for adoption friction and learning curves. 
                    Conservative scenarios (70% multiplier) model the reality that not all process steps automate perfectly on day one.
                  </p>
                </div>

                <div className="bg-muted p-4 rounded-md">
                  <div className="flex items-center gap-2 mb-2">
                    <Badge variant="secondary" className="text-xs">Benefit Multiplier 2</Badge>
                  </div>
                  <h5 className="font-semibold mb-2">Error Reduction Multiplier</h5>
                  <div className="text-xs space-y-1">
                    <div className="flex justify-between">
                      <span>• Best Case:</span>
                      <strong>120%</strong>
                    </div>
                    <div className="flex justify-between">
                      <span>• Base Case:</span>
                      <strong>100%</strong>
                    </div>
                    <div className="flex justify-between">
                      <span>• Conservative:</span>
                      <strong>70%</strong>
                    </div>
                    <div className="flex justify-between">
                      <span>• Worst Case:</span>
                      <strong>50%</strong>
                    </div>
                  </div>
                  <p className="text-xs text-muted-foreground mt-2">
                    <strong>Why this matters:</strong> AI can sometimes catch MORE errors than expected (120% best case), especially in 
                    structured processes. Conservative scenarios account for partial automation and edge cases AI might miss.
                  </p>
                </div>

                <div className="bg-muted p-4 rounded-md">
                  <div className="flex items-center gap-2 mb-2">
                    <Badge variant="secondary" className="text-xs">Benefit Multiplier 3</Badge>
                  </div>
                  <h5 className="font-semibold mb-2">Reallocation Multiplier (Revenue)</h5>
                  <div className="text-xs space-y-1">
                    <div className="flex justify-between">
                      <span>• Best Case:</span>
                      <strong>100%</strong>
                    </div>
                    <div className="flex justify-between">
                      <span>• Base Case:</span>
                      <strong>70%</strong>
                    </div>
                    <div className="flex justify-between">
                      <span>• Conservative:</span>
                      <strong>40%</strong>
                    </div>
                    <div className="flex justify-between">
                      <span>• Worst Case:</span>
                      <strong>0%</strong>
                    </div>
                  </div>
                  <p className="text-xs text-muted-foreground mt-2">
                    <strong>Why this matters:</strong> Converting saved time to revenue is the HARDEST benefit to realize (most conservative multipliers). 
                    Even in base case (70%), only 70% of the rubric-estimated reallocation actually converts to revenue.
                  </p>
                </div>

                <div className="bg-muted p-4 rounded-md">
                  <div className="flex items-center gap-2 mb-2">
                    <Badge variant="secondary" className="text-xs">Cost Multiplier</Badge>
                  </div>
                  <h5 className="font-semibold mb-2">Cost Overrun Multiplier</h5>
                  <div className="text-xs space-y-1">
                    <div className="flex justify-between">
                      <span>• Best Case:</span>
                      <strong>95%</strong>
                    </div>
                    <div className="flex justify-between">
                      <span>• Base Case:</span>
                      <strong>100%</strong>
                    </div>
                    <div className="flex justify-between">
                      <span>• Conservative:</span>
                      <strong>110%</strong>
                    </div>
                    <div className="flex justify-between">
                      <span>• Worst Case:</span>
                      <strong>120%</strong>
                    </div>
                  </div>
                  <p className="text-xs text-muted-foreground mt-2">
                    <strong>Why this matters:</strong> Implementation costs can vary based on scope creep and integration complexity. 
                    Conservative scenarios (110%) model typical cost overruns seen in SME AI projects.
                  </p>
                </div>

                <div className="bg-muted p-4 rounded-md col-span-full">
                  <div className="flex items-center gap-2 mb-2">
                    <Badge variant="secondary" className="text-xs">Ramp-Up Multiplier</Badge>
                  </div>
                  <h5 className="font-semibold mb-2">Ramp-Up Efficiency Multiplier</h5>
                  <div className="text-xs space-y-1">
                    <div className="flex justify-between">
                      <span>• Best Case:</span>
                      <strong>115%</strong>
                    </div>
                    <div className="flex justify-between">
                      <span>• Base Case:</span>
                      <strong>100%</strong>
                    </div>
                    <div className="flex justify-between">
                      <span>• Conservative:</span>
                      <strong>80%</strong>
                    </div>
                    <div className="flex justify-between">
                      <span>• Worst Case:</span>
                      <strong>70%</strong>
                    </div>
                  </div>
                  <p className="text-xs text-muted-foreground mt-2">
                    <strong>Why this matters:</strong> Only affects Year 1 ROI - adjusts benefit realization during implementation period based on 
                    complexity, user comfort, rollout approach, and support. Years 2-5 always achieve 100% run-rate (no ramp-up adjustment).
                  </p>
                </div>
              </div>
            </div>

            <Separator />

            <div>
              <h4 className="font-semibold mb-3">How Multipliers Interact with Each Calculation Step</h4>
              <p className="text-xs text-muted-foreground mb-3">
                Each benefit and cost is calculated independently, then multiplied by its corresponding scenario multiplier. 
                This ensures realistic adjustments across all scenarios while maintaining mathematical transparency.
              </p>
              
              <div className="space-y-3">
                <div className="bg-background p-3 rounded-md border">
                  <p className="text-sm font-semibold mb-1">Time Savings Calculation</p>
                  <p className="text-xs font-mono bg-muted p-2 rounded">
                    Final Time Saved = (Hours Saved × Scenario Time Multiplier)
                  </p>
                  <p className="text-xs text-muted-foreground mt-2">
                    Example: 100 hours saved × 70% (Conservative) = 70 effective hours saved. The 30-hour reduction accounts for 
                    incomplete automation, user errors during learning curve, and process exceptions AI can't handle.
                  </p>
                </div>

                <div className="bg-background p-3 rounded-md border">
                  <p className="text-sm font-semibold mb-1">Error Reduction Calculation</p>
                  <p className="text-xs font-mono bg-muted p-2 rounded">
                    Final Error Savings = (Errors Avoided × Cost Per Error × Scenario Error Multiplier)
                  </p>
                  <p className="text-xs text-muted-foreground mt-2">
                    Example: 50 errors × $200/error × 100% (Base Case) = $10,000 error savings. Base case uses 100% multiplier 
                    because rubric percentages are already conservative - scenario multipliers model variance in adoption success.
                  </p>
                </div>

                <div className="bg-background p-3 rounded-md border">
                  <p className="text-sm font-semibold mb-1">Revenue Uplift Calculation (Double-Layer Conservatism)</p>
                  <p className="text-xs font-mono bg-muted p-2 rounded">
                    Final Revenue Hours = (Hours Saved × Rubric % / 100 × Scenario Reallocation Multiplier)
                  </p>
                  <p className="text-xs text-muted-foreground mt-2">
                    Example: 100 hours × 60% (rubric) × 70% (Base Case) = 42 hours reallocated to revenue. This double-layer approach 
                    (rubric percentage × scenario multiplier) ensures highly conservative revenue estimates that withstand CFO scrutiny.
                  </p>
                </div>

                <div className="bg-background p-3 rounded-md border">
                  <p className="text-sm font-semibold mb-1">Cost Calculation</p>
                  <p className="text-xs font-mono bg-muted p-2 rounded">
                    Final Costs = Base Costs × Scenario Cost Multiplier
                  </p>
                  <p className="text-xs text-muted-foreground mt-2">
                    Example: $50,000 base costs × 1.10 (Conservative) = $55,000 adjusted costs. The 10% increase models typical 
                    scope creep, integration complexity, and unforeseen technical challenges in SME AI implementations.
                  </p>
                </div>
              </div>
            </div>
          </div>

          <Separator />

          {/* Part B: Granular Business Impact Calculations */}
          <div className="space-y-4">
            <h3 className="text-lg font-semibold flex items-center gap-2">
              <Calculator className="h-5 w-5 text-primary" />
              Part B: Granular Business Impact Calculations
            </h3>
            
            <p className="text-sm text-muted-foreground">
              Beyond headline ROI figures, the calculator provides granular business metrics that help you understand 
              <strong> exactly where value is created</strong>. These metrics are scenario-adjusted and capped at 
              physical limits to ensure realistic projections.
            </p>

            {/* Time Efficiency Metrics */}
            <div className="space-y-3">
              <h4 className="font-semibold flex items-center gap-2">
                <Badge variant="outline" className="text-xs">Time Efficiency</Badge>
                Automation Time Savings Metrics
              </h4>
              <div className="bg-muted p-4 rounded-md space-y-3">
                <div>
                  <p className="text-sm font-semibold mb-1">Time Savings Percentage</p>
                  <p className="text-xs font-mono bg-background p-2 rounded mb-2">
                    Base % (from input or Rubric) × Scenario Time Multiplier (capped at 100%)
                  </p>
                  <p className="text-xs text-muted-foreground">
                    Percentage of process time eliminated by automation. Example: 60% base × 70% conservative = 42% effective savings.
                    Multipliers account for adoption curves and learning friction.
                  </p>
                </div>

                <div>
                  <p className="text-sm font-semibold mb-1">Hours Saved (Weekly & Annually)</p>
                  <p className="text-xs font-mono bg-background p-2 rounded mb-2">
                    Total Process Hours × (Scenario-Adjusted Time Savings % ÷ 100)
                  </p>
                  <p className="text-xs text-muted-foreground">
                    Absolute time reclaimed per week/year. Example: 100 total hours × 42% savings = 42 hours/week = 2,184 hours/year.
                    This forms the basis for both cost savings and potential revenue reallocation.
                  </p>
                </div>
              </div>
            </div>

            <Separator />

            {/* Quality Impact Metrics */}
            <div className="space-y-3">
              <h4 className="font-semibold flex items-center gap-2">
                <Badge variant="outline" className="text-xs">Quality Impact</Badge>
                Consolidated Error Reduction Metrics
              </h4>
              <div className="bg-muted p-4 rounded-md space-y-3">
                <div>
                  <p className="text-sm font-semibold mb-1">Error Reduction Percentage</p>
                  <p className="text-xs font-mono bg-background p-2 rounded mb-2">
                    (Error Rate Reduction ÷ Current Error Rate) × 100
                  </p>
                  <p className="text-xs text-muted-foreground">
                    Shows the percentage decrease in error rate. Example: Current 10% error rate → Post-AI 3% = 70% reduction.
                    Scenario-adjusted and capped to prevent impossible values (cannot exceed 100%).
                  </p>
                </div>

                <div>
                  <p className="text-sm font-semibold mb-1">Errors Avoided Annually</p>
                  <p className="text-xs font-mono bg-background p-2 rounded mb-2">
                    (Error Rate Reduction × Transactions Per Week × 52 weeks) ÷ 100
                  </p>
                  <p className="text-xs text-muted-foreground">
                    Absolute count of errors prevented per year. Example: 7% error reduction × 1,000 transactions/week × 52 = 3,640 errors avoided.
                    This drives both rework savings and quality improvement value.
                  </p>
                </div>

                <div>
                  <p className="text-sm font-semibold mb-1">Quality Improvement Percentage</p>
                  <p className="text-xs font-mono bg-background p-2 rounded mb-2">
                    From Quality Impact Rubric (5-95% range, process-type dependent)
                  </p>
                  <p className="text-xs text-muted-foreground">
                    When using the rubric, this shows the overall quality improvement potential based on process characteristics.
                    Scenario multipliers adjust this percentage (with 100% cap) to reflect realistic implementation outcomes.
                  </p>
                </div>

                <div>
                  <p className="text-sm font-semibold mb-1">Post-AI Error Rate</p>
                  <p className="text-xs font-mono bg-background p-2 rounded mb-2">
                    Current Error Rate - (Scenario-Adjusted Error Rate Reduction)
                  </p>
                  <p className="text-xs text-muted-foreground">
                    The projected error rate after AI implementation. Example: 10% current → 70% reduction (scenario-adjusted) → 3% post-AI.
                    Cannot go below 0% even in optimistic scenarios.
                  </p>
                </div>
              </div>
            </div>

            <Separator />

            {/* Revenue Generation Metrics */}
            <div className="space-y-3">
              <h4 className="font-semibold flex items-center gap-2">
                <Badge variant="outline" className="text-xs">Revenue Generation</Badge>
                Time-to-Revenue Conversion Metrics
              </h4>
              <div className="bg-muted p-4 rounded-md space-y-3">
                <div>
                  <p className="text-sm font-semibold mb-1">Hours Reallocated to Revenue Activities</p>
                  <p className="text-xs font-mono bg-background p-2 rounded mb-2">
                    Hours Saved Weekly × 52 weeks × (Scenario-Adjusted Reallocation % ÷ 100)
                  </p>
                  <p className="text-xs text-muted-foreground">
                    Annual hours redirected to revenue-generating work. Example: 20 hours/week saved × 52 × 42% reallocation = 436 hours/year.
                    This quantifies operational leverage gained from automation.
                  </p>
                </div>

                <div>
                  <p className="text-sm font-semibold mb-1">Revenue Reallocation Percentage</p>
                  <p className="text-xs font-mono bg-background p-2 rounded mb-2">
                    Base % (from Rubric) × Scenario Reallocation Multiplier (capped at 100%)
                  </p>
                  <p className="text-xs text-muted-foreground">
                    Percentage of saved time that converts to revenue activities. Example: 60% rubric × 70% base scenario = 42%.
                    Conservative scenarios (40% multiplier) reflect implementation friction and reallocation challenges.
                  </p>
                </div>

                <div>
                  <p className="text-sm font-semibold mb-1">Revenue Value Generated</p>
                  <p className="text-xs font-mono bg-background p-2 rounded mb-2">
                    Hours Reallocated × Effective Hourly Rate
                  </p>
                  <p className="text-xs text-muted-foreground">
                    Total incremental revenue from reallocated capacity. The Effective Hourly Rate (employee's hourly cost including salary + overhead) is used as a conservative proxy for revenue value. Example: 436 hours × $31.73/hour = $13,834 annual uplift.
                    This metric requires strong evidence of demand and capacity utilization to be credible.
                  </p>
                </div>
              </div>
            </div>

            <div className="bg-yellow-50 dark:bg-yellow-950/20 p-4 rounded-md border border-yellow-200 dark:border-yellow-900">
              <p className="text-sm font-semibold mb-2">🎯 Scenario Adjustment & Capping Logic</p>
              <p className="text-xs text-muted-foreground mb-3">
                <strong>All percentage metrics are scenario-adjusted with physical limits:</strong>
              </p>
              <ul className="text-xs text-muted-foreground space-y-1">
                <li>• <strong>Time Savings %:</strong> Cannot exceed 100% (even in optimistic scenarios)</li>
                <li>• <strong>Error Reduction:</strong> Cannot exceed current error rate (post-AI rate {'≥'} 0%)</li>
                <li>• <strong>Quality Improvement %:</strong> Capped at 100% maximum improvement</li>
                <li>• <strong>Reallocation %:</strong> Cannot exceed 100% of saved time</li>
              </ul>
              <p className="text-xs text-muted-foreground mt-3">
                This ensures that conservative scenarios show realistic reductions while optimistic scenarios don't produce 
                impossible metrics (negative error rates, {'>'}100% reductions, etc.).
              </p>
            </div>
          </div>

          <Separator />

          {/* Part C: Step-by-Step Mathematical Flow */}
          <div className="space-y-4">
            <h3 className="text-lg font-semibold flex items-center gap-2">
              <Target className="h-5 w-5 text-primary" />
              Part C: Step-by-Step Mathematical Flow
            </h3>
            
            <p className="text-sm text-muted-foreground">
              This section walks through the complete calculation process, showing exactly how your inputs transform 
              into final ROI metrics. Each step builds on the previous, creating a transparent audit trail from raw 
              data to business case.
            </p>

            {/* Step 1: Foundation */}
            <div className="bg-primary/5 p-4 rounded-md border border-primary/20">
              <h4 className="font-semibold mb-3 flex items-center gap-2">
                <Badge variant="default" className="text-xs">Step 1</Badge>
                Calculate Effective Hourly Rate
              </h4>
              <div className="space-y-2">
                <p className="text-sm font-mono bg-background p-2 rounded">
                  Effective Hourly Rate = (Annual Salary ÷ Annual Working Hours) × Overhead Multiplier
                </p>
                <p className="text-xs text-muted-foreground">
                  <strong>Example:</strong> ($55,000 ÷ 1,920 hours) × 1.2 = $34.38/hour
                </p>
                <p className="text-xs text-muted-foreground">
                  This represents the true cost per hour including benefits and overhead. It's the foundation for all dollar calculations. Annual working hours should reflect your company's actual work schedule.
                </p>
              </div>
            </div>

            {/* Step 2: Time Savings */}
            <div className="bg-green-50 dark:bg-green-950/20 p-4 rounded-md border border-green-200 dark:border-green-900">
              <h4 className="font-semibold mb-3 flex items-center gap-2">
                <Badge variant="outline" className="text-xs">Step 2</Badge>
                Calculate Time Savings Value
              </h4>
              <div className="space-y-3">
                <div>
                  <p className="text-sm font-semibold mb-1">2a. Apply Scenario Multiplier to Time Savings %</p>
                  <p className="text-sm font-mono bg-background p-2 rounded mb-1">
                    Adjusted Time Savings % = Base % × Scenario Multiplier (capped at 100%)
                  </p>
                  <p className="text-xs text-muted-foreground">
                    <strong>Example:</strong> 60% base × 0.70 conservative = 42% adjusted savings
                  </p>
                </div>
                <div>
                  <p className="text-sm font-semibold mb-1">2b. Calculate Hours Saved</p>
                  <p className="text-sm font-mono bg-background p-2 rounded mb-1">
                    Hours Saved Weekly = Total Process Hours × (Adjusted Time Savings % ÷ 100)
                  </p>
                  <p className="text-xs text-muted-foreground">
                    <strong>Example:</strong> (3 employees × 20 hrs/week) × 42% = 25.2 hours/week saved
                  </p>
                </div>
                <div>
                  <p className="text-sm font-semibold mb-1">2c. Convert to Annual Dollar Value</p>
                  <p className="text-sm font-mono bg-background p-2 rounded mb-1">
                    Annual Time Savings = Hours Saved Weekly × 52 weeks × Effective Hourly Rate
                  </p>
                  <p className="text-xs text-muted-foreground">
                    <strong>Example:</strong> 25.2 × 52 × $31.73 = $41,586 annual time savings
                  </p>
                </div>
              </div>
            </div>

            {/* Step 3: Quality Impact */}
            <div className="bg-blue-50 dark:bg-blue-950/20 p-4 rounded-md border border-blue-200 dark:border-blue-900">
              <h4 className="font-semibold mb-3 flex items-center gap-2">
                <Badge variant="outline" className="text-xs">Step 3</Badge>
                Calculate Quality Impact Value
              </h4>
              <div className="space-y-3">
                <div>
                  <p className="text-sm font-semibold mb-1">3a. Determine Error Rate Reduction</p>
                  <p className="text-sm font-mono bg-background p-2 rounded mb-1">
                    Error Rate Reduction % = Base % × Scenario Error Multiplier (capped appropriately)
                  </p>
                  <p className="text-xs text-muted-foreground">
                    <strong>Example:</strong> 10% current error rate → 7% reduction (scenario-adjusted)
                  </p>
                </div>
                <div>
                  <p className="text-sm font-semibold mb-1">3b. Calculate Errors Avoided</p>
                  <p className="text-sm font-mono bg-background p-2 rounded mb-1">
                    Errors Avoided Annually = (Error Reduction % × Weekly Transactions × 52) ÷ 100
                  </p>
                  <p className="text-xs text-muted-foreground">
                    <strong>Example:</strong> (7% × 1,000 transactions/week × 52) ÷ 100 = 3,640 errors avoided
                  </p>
                </div>
                <div>
                  <p className="text-sm font-semibold mb-1">3c. Convert to Dollar Value</p>
                  <p className="text-sm font-mono bg-background p-2 rounded mb-1">
                    Annual Quality Impact = Errors Avoided × Hours Per Rework × Effective Hourly Rate
                  </p>
                  <p className="text-xs text-muted-foreground">
                    <strong>Example:</strong> 3,640 errors × 2 hours × $31.73 = $23,100 annual quality benefit
                  </p>
                </div>
              </div>
            </div>

            {/* Step 4: Revenue Uplift */}
            <div className="bg-purple-50 dark:bg-purple-950/20 p-4 rounded-md border border-purple-200 dark:border-purple-900">
              <h4 className="font-semibold mb-3 flex items-center gap-2">
                <Badge variant="outline" className="text-xs">Step 4</Badge>
                Calculate Revenue Uplift (If Enabled)
              </h4>
              <div className="space-y-3">
                <div>
                  <p className="text-sm font-semibold mb-1">4a. Determine Reallocation %</p>
                  <p className="text-sm font-mono bg-background p-2 rounded mb-1">
                    Reallocation % = Rubric % × Scenario Reallocation Multiplier (capped at 100%)
                  </p>
                  <p className="text-xs text-muted-foreground">
                    <strong>Example:</strong> 60% rubric × 0.70 base = 42% reallocation rate
                  </p>
                </div>
                <div>
                  <p className="text-sm font-semibold mb-1">4b. Calculate Hours Reallocated</p>
                  <p className="text-sm font-mono bg-background p-2 rounded mb-1">
                    Hours Reallocated Annually = Hours Saved Weekly × 52 × (Reallocation % ÷ 100)
                  </p>
                  <p className="text-xs text-muted-foreground">
                    <strong>Example:</strong> 25.2 hours/week × 52 × 42% = 550 hours/year reallocated
                  </p>
                </div>
                <div>
                  <p className="text-sm font-semibold mb-1">4c. Convert to Revenue Value</p>
                  <p className="text-sm font-mono bg-background p-2 rounded mb-1">
                    Annual Revenue Uplift = Hours Reallocated × Effective Hourly Rate
                  </p>
                  <p className="text-xs text-muted-foreground">
                    <strong>Example:</strong> 550 hours × $31.73/hour (employee's hourly cost) = $17,452 annual revenue uplift
                  </p>
                  <p className="text-xs text-muted-foreground mt-1">
                    <strong>Note:</strong> The Effective Hourly Rate represents the employee's total hourly cost (salary + overhead). This conservative approach values reallocated time at cost rather than potential revenue, ensuring defensible estimates.
                  </p>
                </div>
              </div>
            </div>

            {/* Step 5: Total Benefits */}
            <div className="bg-primary/5 p-4 rounded-md border border-primary/20">
              <h4 className="font-semibold mb-3 flex items-center gap-2">
                <Badge variant="default" className="text-xs">Step 5</Badge>
                Sum Total Annual Benefits
              </h4>
              <div className="space-y-2">
                <p className="text-sm font-mono bg-background p-2 rounded">
                  Total Annual Benefits = Time Savings + Quality Impact + Revenue Uplift
                </p>
                <p className="text-xs text-muted-foreground">
                  <strong>Example:</strong> $41,586 + $23,100 + $82,500 = $147,186 total annual benefits
                </p>
                <p className="text-xs text-muted-foreground">
                  This represents the full value created by the AI implementation across all three benefit categories.
                </p>
              </div>
            </div>

            {/* Step 6: Costs */}
            <div className="bg-orange-50 dark:bg-orange-950/20 p-4 rounded-md border border-orange-200 dark:border-orange-900">
              <h4 className="font-semibold mb-3 flex items-center gap-2">
                <Badge variant="outline" className="text-xs">Step 6</Badge>
                Calculate Total Costs (Scenario-Adjusted)
              </h4>
              <div className="space-y-3">
                <div>
                  <p className="text-sm font-semibold mb-1">6a. Apply Cost Overrun Multiplier</p>
                  <p className="text-sm font-mono bg-background p-2 rounded mb-1">
                    Adjusted Costs = Base Costs × Scenario Cost Multiplier
                  </p>
                  <p className="text-xs text-muted-foreground">
                    <strong>Example:</strong> $50,000 base costs × 1.10 conservative = $55,000 adjusted costs
                  </p>
                </div>
                <div>
                  <p className="text-sm font-semibold mb-1">6b. Break Down Cost Components</p>
                  <ul className="text-xs text-muted-foreground space-y-1">
                    <li>• Implementation Cost: One-time (Year 1 only)</li>
                    <li>• Annual Software Cost: Recurring (every year)</li>
                    <li>• Training Cost: One-time (Year 1 only)</li>
                    <li>• Change Management: One-time (Year 1 only)</li>
                  </ul>
                </div>
              </div>
            </div>

            {/* Step 7: ROI Calculation */}
            <div className="bg-primary/5 p-4 rounded-md border border-primary/20">
              <h4 className="font-semibold mb-3 flex items-center gap-2">
                <Badge variant="default" className="text-xs">Step 7</Badge>
                Calculate Final ROI Metrics
              </h4>
              <div className="space-y-3">
                <div>
                  <p className="text-sm font-semibold mb-1">7a. Net Benefits</p>
                  <p className="text-sm font-mono bg-background p-2 rounded mb-1">
                    Annual Net Benefits = Total Annual Benefits - Annual Recurring Costs
                  </p>
                  <p className="text-xs text-muted-foreground">
                    <strong>Example:</strong> $147,186 - $12,000 (software) = $135,186 annual net benefit
                  </p>
                </div>
                <div>
                  <p className="text-sm font-semibold mb-1">7b. ROI Percentage</p>
                  <p className="text-sm font-mono bg-background p-2 rounded mb-1">
                    ROI % = (Annual Net Benefits ÷ Total Implementation Costs) × 100
                  </p>
                  <p className="text-xs text-muted-foreground">
                    <strong>Example:</strong> ($135,186 ÷ $55,000) × 100 = 246% ROI
                  </p>
                </div>
                <div>
                  <p className="text-sm font-semibold mb-1">7c. Payback Period</p>
                  <p className="text-sm font-mono bg-background p-2 rounded mb-1">
                    Payback Months = (Total Costs ÷ Monthly Net Benefits)
                  </p>
                  <p className="text-xs text-muted-foreground">
                    <strong>Example:</strong> $55,000 ÷ ($135,186 ÷ 12) = 4.9 months to break even
                  </p>
                </div>
              </div>
            </div>

            <div className="bg-yellow-50 dark:bg-yellow-950/20 p-4 rounded-md border border-yellow-200 dark:border-yellow-900">
              <p className="text-sm font-semibold mb-2">📊 Key Principle: Layered Conservatism</p>
              <p className="text-xs text-muted-foreground">
                Every calculation follows this exact sequence: <strong>Base inputs → Scenario multipliers → Physical caps → Dollar conversion</strong>. 
                This ensures all results are conservative, realistic, and auditable. The two-layer conservatism (rubric estimates + scenario 
                multipliers) provides defensible ROI projections that withstand scrutiny from finance teams and executive stakeholders.
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
      {/* 11. Company Handbook Download */}
      <Card className="border-primary/20 bg-primary/5">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <FileText className="h-5 w-5 text-primary" />
            Internal Company Documentation
          </CardTitle>
          <CardDescription>
            Download the complete technical and business handbook for this ROI Calculator
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="text-sm text-muted-foreground">
              <p className="mb-2">
                This comprehensive handbook includes detailed operational guidance, calculation methodologies, 
                technical architecture, and strategic implementation advice for the ROI Calculator application.
              </p>
              <p>
                <strong>Contents include:</strong> How to use in client engagements, why calculations build credibility, 
                module toggle strategies, scenario modeling techniques, sensitivity analysis, and complete technical documentation.
              </p>
            </div>
            <Button 
              onClick={() => generateCompanyHandbook()}
              className="gap-2"
              data-testid="button-download-handbook"
            >
              <Download className="h-4 w-4" />
              Download Company Handbook
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
