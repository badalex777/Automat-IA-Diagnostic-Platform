import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Label } from '@/components/ui/label';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { CheckCircle, Calculator, TrendingUp } from 'lucide-react';

interface QuestionOption {
  id: string;
  label: string;
  weight: number;
}

interface Question {
  id: string;
  text: string;
  options: QuestionOption[];
}

const questions: Question[] = [
  {
    id: 'complexity',
    text: 'Q1: How complex is this AI implementation?',
    options: [
      { 
        id: 'low', 
        label: 'Low - Simple automation of existing digital process', 
        weight: 1.1 
      },
      { 
        id: 'moderate', 
        label: 'Moderate - Some process redesign and integration required', 
        weight: 1.0 
      },
      { 
        id: 'high', 
        label: 'High - Major workflow transformation across multiple systems', 
        weight: 0.85 
      },
      { 
        id: 'very_high', 
        label: 'Very High - Enterprise-wide transformation with significant change', 
        weight: 0.7 
      }
    ]
  },
  {
    id: 'digitalComfort',
    text: 'Q2: How comfortable do you feel adopting new tools or digital solutions at work?',
    options: [
      { 
        id: 'very_uncomfortable', 
        label: 'Very uncomfortable - Prefer traditional methods', 
        weight: 0.7 
      },
      { 
        id: 'somewhat_uncomfortable', 
        label: 'Somewhat uncomfortable - Need significant support', 
        weight: 0.85 
      },
      { 
        id: 'neutral', 
        label: 'Neutral - Can adapt with guidance', 
        weight: 1.0 
      },
      { 
        id: 'comfortable', 
        label: 'Comfortable - Quick to learn', 
        weight: 1.1 
      },
      { 
        id: 'very_comfortable', 
        label: 'Very comfortable - Early adopter', 
        weight: 1.2 
      }
    ]
  },
  {
    id: 'rolloutApproach',
    text: 'Q3: What is your implementation rollout strategy?',
    options: [
      { 
        id: 'pilot_first', 
        label: 'Pilot First - Test with small group, then gradual rollout with lessons learned', 
        weight: 1.1 
      },
      { 
        id: 'phased', 
        label: 'Phased - Gradual rollout across departments or teams', 
        weight: 1.0 
      },
      { 
        id: 'parallel', 
        label: 'Parallel - Run old and new processes side-by-side during transition', 
        weight: 0.9 
      },
      { 
        id: 'bigbang', 
        label: 'Big Bang - Switch all users/processes at once on go-live date', 
        weight: 0.8 
      }
    ]
  },
  {
    id: 'supportStructure',
    text: 'Q4: What support structure is in place for implementation?',
    options: [
      { 
        id: 'strong', 
        label: 'Strong - Dedicated change team, executive sponsor, clear governance', 
        weight: 1.1 
      },
      { 
        id: 'basic', 
        label: 'Basic - Some support resources, ad-hoc governance structure', 
        weight: 0.95 
      },
      { 
        id: 'minimal', 
        label: 'Minimal - Limited support, mostly self-service/DIY implementation', 
        weight: 0.8 
      }
    ]
  }
];

interface RampUpEfficiencyRubricProps {
  value: number; // Current efficiency percentage (20-150)
  onChange: (value: number) => void;
  rubricAnswers: {
    complexity: string;
    digitalComfort: string;
    rolloutApproach: string;
    supportStructure: string;
  };
  onRubricChange: (answers: any) => void;
}

export default function RampUpEfficiencyRubric({ 
  value, 
  onChange, 
  rubricAnswers,
  onRubricChange 
}: RampUpEfficiencyRubricProps) {
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [answers, setAnswers] = useState<Record<string, string>>(rubricAnswers || {
    complexity: 'moderate',
    digitalComfort: 'neutral',
    rolloutApproach: 'phased',
    supportStructure: 'basic'
  });

  const calculateEfficiency = (currentAnswers: Record<string, string>) => {
    // Base efficiency is 100%
    let baseEfficiency = 100;
    
    // Get multipliers for each question
    const multipliers = questions.map(q => {
      const selectedOption = q.options.find(opt => opt.id === currentAnswers[q.id]);
      return selectedOption?.weight || 1.0;
    });
    
    // Multiply all factors together (not averaging - this allows for truly conservative results)
    const combinedMultiplier = multipliers.reduce((product, m) => product * m, 1.0);
    
    // Apply to base efficiency
    const calculatedEfficiency = baseEfficiency * combinedMultiplier;
    
    // Cap between 20% (realistic floor for delayed rollouts) and 150% (optimistic ceiling)
    return Math.max(20, Math.min(150, Math.round(calculatedEfficiency)));
  };

  const handleAnswerChange = (questionId: string, answerId: string) => {
    const newAnswers = { ...answers, [questionId]: answerId };
    setAnswers(newAnswers);
    onRubricChange(newAnswers);
    
    // Auto-calculate efficiency
    const calculatedEfficiency = calculateEfficiency(newAnswers);
    onChange(calculatedEfficiency);
  };

  const currentQ = questions[currentQuestion];
  const allAnswered = questions.every(q => answers[q.id]);
  const calculatedEfficiency = calculateEfficiency(answers);

  return (
    <Card className="border-primary/20 bg-primary/5">
      <CardHeader>
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <TrendingUp className="h-5 w-5 text-primary" />
            <CardTitle className="text-lg">
              Implementation Efficiency Assessment
            </CardTitle>
          </div>
          <Badge variant="outline" className="bg-background">
            Question {currentQuestion + 1}/{questions.length}
          </Badge>
        </div>
        <CardDescription>
          Assess how smoothly your AI implementation will roll out. This affects the adoption speed during your ramp-up period.
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Question Navigation */}
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <Label className="text-base font-medium">
              {currentQ.text}
            </Label>
          </div>
          
          <RadioGroup
            value={answers[currentQ.id] || ''}
            onValueChange={(answerId) => handleAnswerChange(currentQ.id, answerId)}
          >
            <div className="space-y-3">
              {currentQ.options.map((option) => (
                <div key={option.id} className="flex items-start space-x-2">
                  <RadioGroupItem value={option.id} id={`${currentQ.id}-${option.id}`} />
                  <Label
                    htmlFor={`${currentQ.id}-${option.id}`}
                    className="font-normal cursor-pointer leading-relaxed"
                  >
                    {option.label}
                  </Label>
                </div>
              ))}
            </div>
          </RadioGroup>
        </div>

        {/* Navigation Buttons */}
        <div className="flex items-center justify-between pt-4">
          <Button
            variant="outline"
            onClick={() => setCurrentQuestion(Math.max(0, currentQuestion - 1))}
            disabled={currentQuestion === 0}
            data-testid="button-rubric-previous"
          >
            Previous
          </Button>
          
          {currentQuestion < questions.length - 1 ? (
            <Button
              onClick={() => setCurrentQuestion(currentQuestion + 1)}
              disabled={!answers[currentQ.id]}
              data-testid="button-rubric-next"
            >
              Next
            </Button>
          ) : (
            <div className="flex items-center gap-2">
              {allAnswered && (
                <CheckCircle className="h-5 w-5 text-green-600" />
              )}
              <span className="text-sm text-muted-foreground">
                Assessment complete
              </span>
            </div>
          )}
        </div>

        {/* Calculated Efficiency Result */}
        {allAnswered && (
          <div className="mt-6 p-4 bg-muted/50 rounded-md space-y-2">
            <div className="flex items-center gap-2">
              <Calculator className="h-4 w-4 text-primary" />
              <span className="font-medium">
                Calculated Implementation Efficiency:
              </span>
              <Badge variant="secondary" className="text-base" data-testid="badge-calculated-efficiency">
                {calculatedEfficiency}%
              </Badge>
            </div>
            <p className="text-xs text-muted-foreground">
              This efficiency will be applied to your base ramp-up factor. Higher values indicate faster adoption during the implementation period.
            </p>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
