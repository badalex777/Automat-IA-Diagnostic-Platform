import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Label } from '@/components/ui/label';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { CheckCircle, Circle, Calculator } from 'lucide-react';
import { ROLE_PROFILES, getRoleProfile } from '@/lib/roleConstants';

interface QuestionOption {
  id: string;
  label: string;
  weight: number;
}

interface Question {
  id: string;
  text: string;
  options: QuestionOption[];
}

const questions: Question[] = [
  {
    id: 'role_type',
    text: 'What type of process will be automated?',
    options: [
      { id: 'data_entry_admin', label: 'Data Entry Clerk / Admin Assistant', weight: 0 },
      { id: 'accounts_payable_receivable', label: 'Accounts Payable/Receivable Clerk', weight: 1 },
      { id: 'payroll_specialist', label: 'Payroll Specialist / Coordinator', weight: 2 },
      { id: 'customer_support_t1', label: 'Customer Support Agent (Tier 1)', weight: 3 },
      { id: 'sales_ops_crm', label: 'Sales Operations / CRM Administrator', weight: 4 },
      { id: 'procurement_purchasing', label: 'Procurement / Purchasing Agent', weight: 5 },
      { id: 'hr_coordinator', label: 'HR Coordinator / Generalist', weight: 6 },
      { id: 'it_support_helpdesk', label: 'IT Support / Help Desk (Tier 1-2)', weight: 7 },
      { id: 'operations_coordinator', label: 'Operations Coordinator / Analyst', weight: 8 },
      { id: 'marketing_ops', label: 'Marketing Operations Specialist', weight: 9 },
      { id: 'financial_analyst', label: 'Financial Analyst / FP&A', weight: 10 },
      { id: 'customer_success', label: 'Customer Success Manager', weight: 11 },
      { id: 'executive_assistant', label: 'Executive Assistant / Office Manager', weight: 12 },
      { id: 'compliance_qa_audit', label: 'Compliance / QA / Audit Specialist', weight: 13 },
      { id: 'legal_contract_admin', label: 'Legal / Contract Administrator', weight: 14 },
      { id: 'other', label: 'Other (specify in comments)', weight: 15 }
    ]
  },
  {
    id: 'complexity',
    text: 'How complex is the task?',
    options: [
      { id: 'simple', label: 'Simple - Follows clear rules and patterns', weight: 1.3 },
      { id: 'moderate', label: 'Moderate - Requires some decision-making', weight: 1.0 },
      { id: 'complex', label: 'Complex - Requires significant analysis', weight: 0.7 }
    ]
  },
  {
    id: 'repetition',
    text: 'How often is this task repeated?',
    options: [
      { id: 'daily', label: 'Daily or multiple times per day', weight: 1.2 },
      { id: 'weekly', label: 'Weekly or a few times per week', weight: 1.0 },
      { id: 'monthly', label: 'Monthly or less frequently', weight: 0.8 }
    ]
  },
  {
    id: 'structure',
    text: 'How structured is the data you work with?',
    options: [
      { id: 'highly_structured', label: 'Highly structured (forms, databases, spreadsheets)', weight: 1.3 },
      { id: 'semi_structured', label: 'Semi-structured (emails, documents with templates)', weight: 1.0 },
      { id: 'unstructured', label: 'Unstructured (free-form text, images, audio)', weight: 0.7 }
    ]
  }
];

interface AITimeSavedRubricProps {
  onTimeSavingsCalculated: (percentage: number) => void;
}

export default function AITimeSavedRubric({ onTimeSavingsCalculated }: AITimeSavedRubricProps) {
  const [currentStep, setCurrentStep] = useState(0);
  const [answers, setAnswers] = useState<Record<string, string>>({});
  const [calculatedPercentage, setCalculatedPercentage] = useState<number | null>(null);
  const [selectedRole, setSelectedRole] = useState<typeof ROLE_PROFILES[0] | null>(null);

  const handleAnswer = (questionId: string, optionId: string) => {
    setAnswers(prev => ({ ...prev, [questionId]: optionId }));
  };

  const goToNextStep = () => {
    if (currentStep < questions.length - 1) {
      setCurrentStep(currentStep + 1);
    } else {
      calculateTimeSavings();
    }
  };

  const goToPreviousStep = () => {
    if (currentStep > 0) {
      setCurrentStep(currentStep - 1);
    }
  };

  const calculateTimeSavings = () => {
    // Validate all questions are answered
    const requiredQuestions = ['role_type', 'complexity', 'repetition', 'structure'];
    const missingAnswers = requiredQuestions.filter(q => !answers[q]);
    
    if (missingAnswers.length > 0) {
      console.error('Cannot calculate: missing answers for', missingAnswers);
      return;
    }

    const roleTypeAnswer = answers['role_type'];
    
    // Get role profile using the role ID
    const roleProfile = getRoleProfile(roleTypeAnswer);
    if (!roleProfile) {
      console.error('Invalid role type:', roleTypeAnswer);
      return;
    }

    // Calculate the final percentage based on all answers
    let basePercentage = roleProfile.timeSavingsBase;
    
    // Apply multipliers from other questions
    const complexityWeight = questions[1].options.find(opt => opt.id === answers['complexity'])?.weight;
    const repetitionWeight = questions[2].options.find(opt => opt.id === answers['repetition'])?.weight;
    const structureWeight = questions[3].options.find(opt => opt.id === answers['structure'])?.weight;
    
    if (complexityWeight === undefined || repetitionWeight === undefined || structureWeight === undefined) {
      console.error('Failed to find weights for answers');
      return;
    }
    
    const finalPercentage = Math.round(basePercentage * complexityWeight * repetitionWeight * structureWeight);
    
    // Extract role-specific bounds from timeSavingsRange
    const rangeParts = roleProfile.timeSavingsRange.match(/(\d+)%\s*-\s*(\d+)%/);
    const minPercent = rangeParts ? parseInt(rangeParts[1]) : 10;
    const maxPercent = rangeParts ? parseInt(rangeParts[2]) : 90;
    
    // Cap the percentage within role-specific bounds
    const cappedPercentage = Math.min(Math.max(finalPercentage, minPercent), maxPercent);
    
    setCalculatedPercentage(cappedPercentage);
    setSelectedRole(roleProfile);
  };

  const applyTimeSavings = () => {
    if (calculatedPercentage !== null) {
      onTimeSavingsCalculated(calculatedPercentage);
    }
  };

  const resetQuestionnaire = () => {
    setCurrentStep(0);
    setAnswers({});
    setCalculatedPercentage(null);
    setSelectedRole(null);
  };

  const currentQuestion = questions[currentStep];
  const isLastStep = currentStep === questions.length - 1;
  const canProceed = answers[currentQuestion?.id];

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Calculator className="h-5 w-5 text-primary" />
          AI Time Saved Rubric
        </CardTitle>
        <CardDescription>
          Answer a few questions to get a personalized time savings estimate
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        {calculatedPercentage === null ? (
          // Questionnaire Flow
          <>
            {/* Progress Indicator */}
            <div className="flex items-center justify-between text-sm text-muted-foreground">
              <span>Question {currentStep + 1} of {questions.length}</span>
              <div className="flex gap-1">
                {questions.map((_, index) => (
                  <div
                    key={index}
                    className={`w-2 h-2 rounded-full ${
                      index <= currentStep ? 'bg-primary' : 'bg-muted'
                    }`}
                  />
                ))}
              </div>
            </div>

            {/* Current Question */}
            <div className="space-y-4">
              <Label className="text-base font-medium">{currentQuestion.text}</Label>
              
              <RadioGroup
                value={answers[currentQuestion.id] || ''}
                onValueChange={(value) => handleAnswer(currentQuestion.id, value)}
                className="space-y-3"
              >
                {currentQuestion.options.map((option) => (
                  <div key={option.id} className="flex items-start space-x-3">
                    <RadioGroupItem
                      value={option.id}
                      id={option.id}
                      className="mt-1"
                      data-testid={`radio-${option.id}`}
                    />
                    <Label 
                      htmlFor={option.id} 
                      className="flex-1 text-sm leading-relaxed cursor-pointer"
                    >
                      {option.label}
                    </Label>
                  </div>
                ))}
              </RadioGroup>
              
              {/* Helper text for "Other" option */}
              {currentQuestion.id === 'role_type' && answers['role_type'] === 'other' && (
                <div className="mt-3 p-3 bg-amber-50 dark:bg-amber-950/20 border border-amber-200 dark:border-amber-900 rounded-md">
                  <p className="text-sm text-amber-800 dark:text-amber-200">
                    💡 <strong>Important:</strong> Please specify the role in your project comments or notes for accurate estimation and future reference.
                  </p>
                </div>
              )}
            </div>

            {/* Navigation Buttons */}
            <div className="flex gap-3">
              <Button
                variant="outline"
                onClick={goToPreviousStep}
                disabled={currentStep === 0}
                className="flex-1"
                data-testid="button-previous"
              >
                Previous
              </Button>
              <Button
                onClick={goToNextStep}
                disabled={!canProceed}
                className="flex-1"
                data-testid={isLastStep ? "button-calculate" : "button-next"}
              >
                {isLastStep ? 'Calculate Savings' : 'Next'}
              </Button>
            </div>
          </>
        ) : (
          // Results Display
          <div className="space-y-6">
            <div className="text-center space-y-4">
              <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-primary/10">
                <CheckCircle className="h-8 w-8 text-primary" />
              </div>
              
              <div>
                <h3 className="text-2xl font-bold text-primary" data-testid="text-calculated-percentage">
                  {calculatedPercentage}%
                </h3>
                <p className="text-sm text-muted-foreground">Estimated Time Savings</p>
              </div>
            </div>

            {selectedRole && (
              <div className="p-4 border rounded-lg bg-muted/20 space-y-3">
                <div className="flex items-center justify-between">
                  <h4 className="font-medium">{selectedRole.role}</h4>
                  <Badge variant="secondary">{selectedRole.timeSavingsRange}</Badge>
                </div>
                <p className="text-sm text-muted-foreground">
                  {selectedRole.description}
                </p>
              </div>
            )}

            <div className="flex gap-3">
              <Button
                variant="outline"
                onClick={resetQuestionnaire}
                className="flex-1"
                data-testid="button-retake"
              >
                Retake Assessment
              </Button>
              <Button
                onClick={applyTimeSavings}
                className="flex-1"
                data-testid="button-apply-savings"
              >
                Apply Time Savings
              </Button>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
