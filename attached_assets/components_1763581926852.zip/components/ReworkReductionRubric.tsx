import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Label } from '@/components/ui/label';
import { Calculator, ArrowLeft, ArrowRight } from 'lucide-react';
import { useState } from 'react';

interface ReworkReductionRubricProps {
  onReductionCalculated: (percentage: number) => void;
}

interface Question {
  id: string;
  text: string;
  options: {
    id: string;
    label: string;
    weight: number;
  }[];
}

interface ProcessCategory {
  category: string;
  description: string;
  reductionRange: string;
  basePercentage: number;
}

const questions: Question[] = [
  {
    id: 'process_type',
    text: 'What type of process will be automated?',
    options: [
      { id: 'data_validation', label: 'Data Entry & Validation', weight: 0 },
      { id: 'document_processing', label: 'Document Processing & Review', weight: 1 },
      { id: 'communication_coordination', label: 'Communication & Coordination', weight: 2 },
      { id: 'research_analysis', label: 'Research & Analysis', weight: 3 },
      { id: 'qa_compliance', label: 'Quality Assurance & Compliance', weight: 4 }
    ]
  },
  {
    id: 'error_frequency',
    text: 'How frequently do errors/issues occur currently?',
    options: [
      { id: 'very_high', label: 'Very High (>30% of outputs need rework)', weight: 1.4 },
      { id: 'high', label: 'High (15-30% of outputs need rework)', weight: 1.2 },
      { id: 'moderate', label: 'Moderate (5-15% of outputs need rework)', weight: 1.0 },
      { id: 'low', label: 'Low (<5% of outputs need rework)', weight: 0.8 }
    ]
  },
  {
    id: 'root_cause',
    text: 'What is the primary cause of rework?',
    options: [
      { id: 'human_error', label: 'Human error/oversight', weight: 1.3 },
      { id: 'incomplete_info', label: 'Incomplete information', weight: 1.1 },
      { id: 'process_gaps', label: 'Process gaps/unclear requirements', weight: 1.2 },
      { id: 'communication', label: 'Communication breakdowns', weight: 0.9 }
    ]
  },
  {
    id: 'detection_point',
    text: 'When are issues typically discovered?',
    options: [
      { id: 'early_stage', label: 'Early in process (quick fixes)', weight: 0.8 },
      { id: 'mid_process', label: 'Mid-process (moderate rework)', weight: 1.0 },
      { id: 'end_process', label: 'End of process (significant rework)', weight: 1.2 },
      { id: 'post_delivery', label: 'Post-delivery (major rework/customer returns)', weight: 1.4 }
    ]
  }
];

const processCategories: ProcessCategory[] = [
  {
    category: 'Data Entry & Validation',
    description: 'Data input, validation, verification, and accuracy checking processes',
    reductionRange: '35% - 75%',
    basePercentage: 55
  },
  {
    category: 'Document Processing & Review',
    description: 'Document review, editing, formatting, and content validation processes',
    reductionRange: '25% - 65%',
    basePercentage: 45
  },
  {
    category: 'Communication & Coordination',
    description: 'Multi-stage approval workflows, coordination, and authorization processes',
    reductionRange: '30% - 70%',
    basePercentage: 50
  },
  {
    category: 'Research & Analysis',
    description: 'Research validation, information verification, and analytical review processes',
    reductionRange: '30% - 70%',
    basePercentage: 50
  },
  {
    category: 'Quality Assurance & Compliance',
    description: 'QA testing, inspection, compliance checks, and regulatory validation',
    reductionRange: '40% - 80%',
    basePercentage: 60
  }
];

// Direct mapping from process type option ID to category index
const processTypeMapping: Record<string, number> = {
  'data_validation': 0,
  'document_processing': 1,
  'communication_coordination': 2,
  'research_analysis': 3,
  'qa_compliance': 4
};

export default function ReworkReductionRubric({ onReductionCalculated }: ReworkReductionRubricProps) {
  const [currentStep, setCurrentStep] = useState(0);
  const [answers, setAnswers] = useState<Record<string, string>>({});
  const [calculatedPercentage, setCalculatedPercentage] = useState<number | null>(null);
  const [selectedCategory, setSelectedCategory] = useState<ProcessCategory | null>(null);

  const handleAnswerChange = (questionId: string, value: string) => {
    setAnswers({ ...answers, [questionId]: value });
  };

  const canProceed = answers[questions[currentStep].id];
  const isLastStep = currentStep === questions.length - 1;

  const goToNextStep = () => {
    if (canProceed) {
      if (isLastStep) {
        calculateReduction();
      } else {
        setCurrentStep(currentStep + 1);
      }
    }
  };

  const goToPreviousStep = () => {
    if (currentStep > 0) {
      setCurrentStep(currentStep - 1);
    }
  };

  const calculateReduction = () => {
    // Validate all questions are answered
    const requiredQuestions = ['process_type', 'error_frequency', 'root_cause', 'detection_point'];
    const missingAnswers = requiredQuestions.filter(q => !answers[q]);
    
    if (missingAnswers.length > 0) {
      console.error('Cannot calculate: missing answers for', missingAnswers);
      return;
    }

    const processTypeAnswer = answers['process_type'];

    // Get category using direct mapping
    const categoryIndex = processTypeMapping[processTypeAnswer];
    if (categoryIndex === undefined) {
      console.error('Invalid process type:', processTypeAnswer);
      return;
    }
    
    const category = processCategories[categoryIndex];
    if (!category) {
      console.error('Category not found for index:', categoryIndex);
      return;
    }

    // Calculate the final percentage based on all answers
    let basePercentage = category.basePercentage;
    
    // Apply multipliers from other questions
    const errorFrequencyWeight = questions[1].options.find(opt => opt.id === answers['error_frequency'])?.weight;
    const rootCauseWeight = questions[2].options.find(opt => opt.id === answers['root_cause'])?.weight;
    const detectionWeight = questions[3].options.find(opt => opt.id === answers['detection_point'])?.weight;
    
    if (errorFrequencyWeight === undefined || rootCauseWeight === undefined || detectionWeight === undefined) {
      console.error('Failed to find weights for answers');
      return;
    }
    
    const finalPercentage = Math.round(basePercentage * errorFrequencyWeight * rootCauseWeight * detectionWeight);
    
    // Extract category-specific bounds from reductionRange
    const rangeParts = category.reductionRange.match(/(\d+)%\s*-\s*(\d+)%/);
    const minPercent = rangeParts ? parseInt(rangeParts[1]) : 10;
    const maxPercent = rangeParts ? parseInt(rangeParts[2]) : 80;
    
    // Cap the percentage within category-specific bounds
    const cappedPercentage = Math.min(Math.max(finalPercentage, minPercent), maxPercent);
    
    setCalculatedPercentage(cappedPercentage);
    setSelectedCategory(category);
  };

  const resetQuestionnaire = () => {
    setCurrentStep(0);
    setAnswers({});
    setCalculatedPercentage(null);
    setSelectedCategory(null);
  };

  const applyReduction = () => {
    if (calculatedPercentage !== null) {
      onReductionCalculated(calculatedPercentage);
    }
  };

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Calculator className="h-5 w-5 text-primary" />
          Rework Reduction Rubric
        </CardTitle>
        <CardDescription>
          Answer questions to get a reliable rework reduction estimate based on process improvement patterns
        </CardDescription>
      </CardHeader>
      <CardContent>
        {calculatedPercentage === null ? (
          <div className="space-y-6">
            <div className="flex items-center justify-between text-sm text-muted-foreground">
              <span>Question {currentStep + 1} of {questions.length}</span>
              <div className="flex space-x-1">
                {questions.map((_, index) => (
                  <div 
                    key={index}
                    className={`w-2 h-2 rounded-full ${
                      index <= currentStep ? 'bg-primary' : 'bg-muted'
                    }`}
                  />
                ))}
              </div>
            </div>
            
            <div className="space-y-4">
              <h3 className="text-lg font-medium">{questions[currentStep].text}</h3>
              
              <RadioGroup 
                value={answers[questions[currentStep].id] || ''} 
                onValueChange={(value) => handleAnswerChange(questions[currentStep].id, value)}
                className="space-y-3"
              >
                {questions[currentStep].options.map((option) => (
                  <div key={option.id} className="flex items-start space-x-2">
                    <RadioGroupItem 
                      value={option.id} 
                      id={option.id}
                      data-testid={`radio-${option.id}`}
                    />
                    <Label 
                      htmlFor={option.id} 
                      className="flex-1 leading-relaxed cursor-pointer"
                    >
                      {option.label}
                    </Label>
                  </div>
                ))}
              </RadioGroup>
            </div>
            
            <div className="flex gap-2 pt-4">
              <Button
                variant="outline"
                onClick={goToPreviousStep}
                disabled={currentStep === 0}
                className="flex-1"
                data-testid="button-previous"
              >
                <ArrowLeft className="h-4 w-4 mr-2" />
                Previous
              </Button>
              <Button
                onClick={goToNextStep}
                disabled={!canProceed}
                className="flex-1"
                data-testid={isLastStep ? "button-calculate" : "button-next"}
              >
                {isLastStep ? (
                  <>
                    <Calculator className="h-4 w-4 mr-2" />
                    Calculate Reduction
                  </>
                ) : (
                  <>
                    Next
                    <ArrowRight className="h-4 w-4 ml-2" />
                  </>
                )}
              </Button>
            </div>
          </div>
        ) : (
          <div className="space-y-4">
            <div className="text-center space-y-2">
              <div className="text-4xl font-bold text-primary" data-testid="text-calculated-percentage">
                {calculatedPercentage}%
              </div>
              <p className="text-sm text-muted-foreground">Estimated Rework Reduction</p>
            </div>
            
            {selectedCategory && (
              <Card className="bg-muted/50">
                <CardContent className="pt-4">
                  <div className="space-y-2">
                    <h4 className="font-medium" data-testid="text-category-name">{selectedCategory.category}</h4>
                    <p className="text-sm text-muted-foreground">{selectedCategory.description}</p>
                    <Badge variant="outline" data-testid="text-category-range">
                      Range: {selectedCategory.reductionRange}
                    </Badge>
                  </div>
                </CardContent>
              </Card>
            )}
            
            <div className="flex gap-2 pt-4">
              <Button
                variant="outline"
                onClick={resetQuestionnaire}
                className="flex-1"
                data-testid="button-retake"
              >
                Retake Assessment
              </Button>
              <Button
                onClick={applyReduction}
                className="flex-1"
                data-testid="button-apply-reduction"
              >
                Apply Reduction
              </Button>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
