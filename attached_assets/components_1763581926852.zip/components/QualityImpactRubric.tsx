import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Label } from '@/components/ui/label';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { CheckCircle, Calculator, Shield } from 'lucide-react';
import { ROLE_PROFILES, getRoleProfile } from '@/lib/roleConstants';

interface QuestionOption {
  id: string;
  label: string;
  weight: number;
}

interface Question {
  id: string;
  text: string;
  options: QuestionOption[];
}

const questions: Question[] = [
  {
    id: 'role_type',
    text: 'What type of work process will be automated?',
    options: [
      { id: 'data_entry_admin', label: 'Data Entry Clerk / Admin Assistant', weight: 0 },
      { id: 'accounts_payable_receivable', label: 'Accounts Payable/Receivable Clerk', weight: 1 },
      { id: 'payroll_specialist', label: 'Payroll Specialist / Coordinator', weight: 2 },
      { id: 'customer_support_t1', label: 'Customer Support Agent (Tier 1)', weight: 3 },
      { id: 'sales_ops_crm', label: 'Sales Operations / CRM Administrator', weight: 4 },
      { id: 'procurement_purchasing', label: 'Procurement / Purchasing Agent', weight: 5 },
      { id: 'hr_coordinator', label: 'HR Coordinator / Generalist', weight: 6 },
      { id: 'it_support_helpdesk', label: 'IT Support / Help Desk (Tier 1-2)', weight: 7 },
      { id: 'operations_coordinator', label: 'Operations Coordinator / Analyst', weight: 8 },
      { id: 'marketing_ops', label: 'Marketing Operations Specialist', weight: 9 },
      { id: 'financial_analyst', label: 'Financial Analyst / FP&A', weight: 10 },
      { id: 'customer_success', label: 'Customer Success Manager', weight: 11 },
      { id: 'executive_assistant', label: 'Executive Assistant / Office Manager', weight: 12 },
      { id: 'compliance_qa_audit', label: 'Compliance / QA / Audit Specialist', weight: 13 },
      { id: 'legal_contract_admin', label: 'Legal / Contract Administrator', weight: 14 },
      { id: 'other', label: 'Other (specify in comments)', weight: 15 }
    ]
  },
  {
    id: 'error_frequency',
    text: 'How often do errors or quality issues currently occur in this process?',
    options: [
      { id: 'very_frequent', label: 'Very frequent - Errors occur in more than 30% of cases', weight: 1.3 },
      { id: 'frequent', label: 'Frequent - Errors occur in 15-30% of cases', weight: 1.15 },
      { id: 'occasional', label: 'Occasional - Errors occur in 5-15% of cases', weight: 1.0 },
      { id: 'rare', label: 'Rare - Errors occur in less than 5% of cases', weight: 0.8 }
    ]
  },
  {
    id: 'error_cause',
    text: 'What is the primary cause of errors or quality issues?',
    options: [
      { id: 'manual_repetitive', label: 'Manual, repetitive work leading to human fatigue or oversight', weight: 1.3 },
      { id: 'information_gaps', label: 'Missing or incomplete information when making decisions', weight: 1.15 },
      { id: 'inconsistent_standards', label: 'Inconsistent interpretation of rules or standards', weight: 1.15 },
      { id: 'complexity', label: 'High complexity requiring significant expertise or judgment', weight: 0.8 },
      { id: 'communication_breakdown', label: 'Communication gaps or misunderstandings between people', weight: 1.0 }
    ]
  },
  {
    id: 'detection_timing',
    text: 'When are errors or quality issues typically discovered?',
    options: [
      { id: 'post_delivery', label: 'After delivery to customer (customer complaints, returns, escalations)', weight: 1.3 },
      { id: 'end_process', label: 'At the end of the process (final review or quality check)', weight: 1.15 },
      { id: 'mid_process', label: 'During the process (spotted before completion)', weight: 1.0 },
      { id: 'early_process', label: 'Early in the process (caught quickly with minimal rework)', weight: 0.8 }
    ]
  },
  {
    id: 'standardization',
    text: 'How standardized is the current process?',
    options: [
      { id: 'highly_variable', label: 'Highly variable - Each case is handled differently', weight: 0.8 },
      { id: 'some_guidelines', label: 'Some guidelines - General approach but flexibility in execution', weight: 1.0 },
      { id: 'documented_process', label: 'Documented process - Clear steps and procedures to follow', weight: 1.15 },
      { id: 'strict_standards', label: 'Strict standards - Detailed rules and quality requirements', weight: 1.3 }
    ]
  },
  {
    id: 'ai_suitability',
    text: 'How well-suited is this work for AI quality improvement?',
    options: [
      { id: 'rule_based', label: 'Rule-based decisions - Clear if/then rules that can be programmed', weight: 1.3 },
      { id: 'pattern_recognition', label: 'Pattern recognition - AI can learn from examples and spot patterns', weight: 1.15 },
      { id: 'contextual_judgment', label: 'Contextual judgment - Requires understanding context and nuance', weight: 1.0 },
      { id: 'highly_subjective', label: 'Highly subjective - Depends heavily on personal opinion or taste', weight: 0.8 }
    ]
  }
];

interface QualityImpactRubricProps {
  onImprovementCalculated: (percentage: number) => void;
}

export default function QualityImpactRubric({ onImprovementCalculated }: QualityImpactRubricProps) {
  const [currentStep, setCurrentStep] = useState(0);
  const [answers, setAnswers] = useState<Record<string, string>>({});
  const [calculatedPercentage, setCalculatedPercentage] = useState<number | null>(null);
  const [selectedRole, setSelectedRole] = useState<typeof ROLE_PROFILES[0] | null>(null);

  const handleAnswer = (questionId: string, optionId: string) => {
    const newAnswers = { ...answers, [questionId]: optionId };
    setAnswers(newAnswers);
  };

  const calculateImprovement = () => {
    const roleTypeAnswer = answers['role_type'];
    if (!roleTypeAnswer) return;

    const roleProfile = getRoleProfile(roleTypeAnswer);
    if (!roleProfile) {
      console.error('Invalid role type:', roleTypeAnswer);
      return;
    }

    setSelectedRole(roleProfile);
    let basePercentage = roleProfile.qualityImpactBase;

    // Apply multipliers from other questions
    const errorFreqWeight = questions[1].options.find(o => o.id === answers['error_frequency'])?.weight || 1.0;
    const errorCauseWeight = questions[2].options.find(o => o.id === answers['error_cause'])?.weight || 1.0;
    const detectionWeight = questions[3].options.find(o => o.id === answers['detection_timing'])?.weight || 1.0;
    const standardizationWeight = questions[4].options.find(o => o.id === answers['standardization'])?.weight || 1.0;
    const aiSuitabilityWeight = questions[5].options.find(o => o.id === answers['ai_suitability'])?.weight || 1.0;

    // Calculate final percentage with multipliers (using arithmetic mean so neutral weights = 1.0 preserves base percentage)
    const combinedMultiplier = (errorFreqWeight + errorCauseWeight + detectionWeight + standardizationWeight + aiSuitabilityWeight) / 5;
    const finalPercentage = Math.round(basePercentage * combinedMultiplier);

    // Extract role-specific bounds from qualityImpactRange
    const rangeParts = roleProfile.qualityImpactRange.match(/(\d+)%\s*-\s*(\d+)%/);
    const minPercent = rangeParts ? parseInt(rangeParts[1]) : 5;
    const maxPercent = rangeParts ? parseInt(rangeParts[2]) : 95;
    
    // Cap the percentage within role-specific bounds
    const cappedPercentage = Math.min(Math.max(finalPercentage, minPercent), maxPercent);
    
    setCalculatedPercentage(cappedPercentage);
  };

  const handleApplyImprovement = () => {
    if (calculatedPercentage !== null) {
      onImprovementCalculated(calculatedPercentage);
    }
  };

  const handleRetake = () => {
    setCurrentStep(0);
    setAnswers({});
    setCalculatedPercentage(null);
    setSelectedRole(null);
  };

  const isQuestionAnswered = (questionId: string) => {
    return answers[questionId] !== undefined;
  };

  const allQuestionsAnswered = questions.every(q => isQuestionAnswered(q.id));

  return (
    <Card className="border-primary/20">
      <CardHeader>
        <div className="flex items-center justify-between">
          <div className="space-y-1">
            <CardTitle className="flex items-center gap-2">
              <Shield className="h-5 w-5 text-primary" />
              Quality Impact Assessment
            </CardTitle>
            <CardDescription>Answer questions about your process to estimate how much AI can improve quality and reduce errors</CardDescription>
          </div>
          {calculatedPercentage === null && (
            <Badge variant="outline">
              Question {currentStep + 1} of {questions.length}
            </Badge>
          )}
        </div>
      </CardHeader>

      <CardContent className="space-y-6">
        {calculatedPercentage === null ? (
          <>
            {questions.map((question, index) => (
              <div key={question.id} className={index === currentStep ? 'block' : 'hidden'}>
                <div className="space-y-4">
                  <div className="flex items-start gap-3">
                    {isQuestionAnswered(question.id) ? (
                      <CheckCircle className="h-5 w-5 text-primary mt-1 flex-shrink-0" />
                    ) : (
                      <div className="h-5 w-5 rounded-full border-2 border-muted-foreground mt-1 flex-shrink-0" />
                    )}
                    <div className="flex-1">
                      <Label className="text-base font-medium">{question.text}</Label>
                    </div>
                  </div>

                  <RadioGroup
                    value={answers[question.id] || ''}
                    onValueChange={(value) => handleAnswer(question.id, value)}
                    className="space-y-3 ml-8"
                  >
                    {question.options.map((option) => (
                      <div key={option.id} className="flex items-start space-x-3 space-y-0">
                        <RadioGroupItem value={option.id} id={`${question.id}-${option.id}`} />
                        <Label
                          htmlFor={`${question.id}-${option.id}`}
                          className="font-normal cursor-pointer flex-1"
                        >
                          {option.label}
                        </Label>
                      </div>
                    ))}
                  </RadioGroup>
                  
                  {/* Helper text for "Other" option */}
                  {question.id === 'process_category' && answers['process_category'] === 'other_specify' && (
                    <div className="mt-3 ml-8 p-3 bg-amber-50 dark:bg-amber-950/20 border border-amber-200 dark:border-amber-900 rounded-md">
                      <p className="text-sm text-amber-800 dark:text-amber-200">
                        💡 <strong>Important:</strong> Please specify the process type in your project comments or notes for accurate estimation and future reference.
                      </p>
                    </div>
                  )}
                </div>
              </div>
            ))}

            <div className="flex gap-3 pt-4">
              {currentStep > 0 && (
                <Button
                  variant="outline"
                  onClick={() => setCurrentStep(currentStep - 1)}
                  data-testid="button-previous-quality-question"
                >
                  Previous
                </Button>
              )}
              {currentStep < questions.length - 1 && isQuestionAnswered(questions[currentStep].id) && (
                <Button
                  onClick={() => setCurrentStep(currentStep + 1)}
                  data-testid="button-next-quality-question"
                >
                  Next
                </Button>
              )}
              {currentStep === questions.length - 1 && allQuestionsAnswered && (
                <Button
                  onClick={calculateImprovement}
                  className="gap-2"
                  data-testid="button-calculate-quality-improvement"
                >
                  <Calculator className="h-4 w-4" />
                  Calculate Quality Improvement
                </Button>
              )}
            </div>
          </>
        ) : (
          <div className="space-y-6">
            {selectedRole && (
              <div className="p-4 bg-muted/50 rounded-lg space-y-3">
                <div className="flex items-start justify-between">
                  <div className="space-y-1">
                    <p className="font-medium text-sm text-muted-foreground">Role Type</p>
                    <p className="text-lg font-semibold">{selectedRole.role}</p>
                  </div>
                  <Badge variant="secondary">{selectedRole.qualityImpactRange}</Badge>
                </div>
                <p className="text-sm text-muted-foreground">{selectedRole.description}</p>
              </div>
            )}

            <div className="flex items-center justify-center p-8 bg-primary/5 rounded-lg border border-primary/20">
              <div className="text-center space-y-2">
                <p className="text-sm font-medium text-muted-foreground">Estimated Quality Improvement</p>
                <p className="text-5xl font-bold text-primary">{calculatedPercentage}%</p>
              </div>
            </div>

            <div className="flex gap-3">
              <Button
                variant="outline"
                onClick={handleRetake}
                className="flex-1"
                data-testid="button-retake-quality-assessment"
              >
                Retake Assessment
              </Button>
              <Button
                onClick={handleApplyImprovement}
                className="flex-1"
                data-testid="button-apply-quality-improvement"
              >
                Apply Improvement
              </Button>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
